
if [ $1 == "saas" ]
then
	echo "Copying JMX exporter to /opt"
	cp -av /opt/prometheus/jmx_exporter-master /opt/prometheus_$1
        mv /opt/prometheus_$1/example_configs/httpserver_sample_config.yml /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        mv /opt/prometheus_$1/run_sample_httpserver.sh /opt/prometheus_$1/run_$1_httpserver.sh
	chmod a+x /opt/prometheus_$1/run_$1_httpserver.sh
 	chown ec2-user:ec2-user /opt/prometheus_$1/run_$1_httpserver.sh
 	jmxport=17001
        export=`expr $jmxport + 10000`
        jxport=`expr $jmxport + 9000`
        echo "generating /opt/prometheus_$1/example_configs/httpserver_$1_config.yml"

        echo "---" > /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo "hostPort: localhost:$jmxport" >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo "username: " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo "password: " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo " " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo "rules:" >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo "- pattern: \".*\"" >>/opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo " " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        cat /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
        echo "generating /opt/prometheus_$1/run_$1_httpserver.sh"

        echo "#!/usr/bin/env bash" > /opt/prometheus_$1/run_$1_httpserver.sh
        echo "# Script to run a java application for testing jmx4prometheus." >> /opt/prometheus_$1/run_$1_httpserver.sh
        echo 'version=$(sed -n -e '"'"'s#.*<version>\(.*-SNAPSHOT\)</version>#\1#p'"'"' pom.xml)' >> /opt/prometheus_$1/run_$1_httpserver.sh
        echo "/appmount/home/icsuser/saas/java/bin/java -jar jmx_prometheus_httpserver/target/jmx_prometheus_httpserver-\${version}-jar-with-dependencies.jar $export example_configs/httpserver_$1_config.yml" >> /opt/prometheus_$1/run_$1_httpserver.sh
        cat /opt/prometheus_$1/run_$1_httpserver.sh

else
	if [ -d /opt/tomcat_$1 ]
	then
	echo "Copying JMX exporter to /opt"
	cp -av /opt/prometheus/jmx_exporter-master /opt/prometheus_$1
	jmxport=`grep jmxremote.port /opt/tomcat_$1/bin/setenv.sh | cut -d "=" -f3 | sed 's/"//'`
	export=`expr $jmxport + 10000`
	jxport=`expr $jmxport + 9000`
	echo "generating /opt/prometheus_$1/example_configs/httpserver_$1_config.yml"

	echo "---" > /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo "hostPort: localhost:$jmxport" >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo "username: " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo "password: " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo " " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo "rules:" >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo "- pattern: \".*\"" >>/opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo " " >> /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	cat /opt/prometheus_$1/example_configs/httpserver_$1_config.yml
	echo "generating /opt/prometheus_$1/run_$1_httpserver.sh"

	echo "#!/usr/bin/env bash" > /opt/prometheus_$1/run_$1_httpserver.sh
	echo "# Script to run a java application for testing jmx4prometheus." >> /opt/prometheus_$1/run_$1_httpserver.sh
	echo 'version=$(sed -n -e '"'"'s#.*<version>\(.*-SNAPSHOT\)</version>#\1#p'"'"' pom.xml)' >> /opt/prometheus_$1/run_$1_httpserver.sh
	echo "java -jar jmx_prometheus_httpserver/target/jmx_prometheus_httpserver-\${version}-jar-with-dependencies.jar $export example_configs/httpserver_$1_config.yml" >> /opt/prometheus_$1/run_$1_httpserver.sh
	cat /opt/prometheus_$1/run_$1_httpserver.sh
	else
	echo "App $1 is not installed"
fi
fi
