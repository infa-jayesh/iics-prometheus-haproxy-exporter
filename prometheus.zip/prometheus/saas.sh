if [ -d /opt/tomcat_$1 ]
then      
        echo "Copying JMX exporter to /opt"
        cp -av /opt/prometheus/jmx_exporter-master /opt/prometheus_$1
        mv /opt/prometheus_$1/example_configs/httpserver_sample_config.yml /opt/prometheus_$1/httpserver_$1_config.yml
        mv /opt/prometheus_$1/run_sample_httpserver.sh /opt/prometheus_$1/run_$1_httpserver.sh
        chmod a+x /opt/prometheus_$1/run_$1_httpserver.sh
        chown ec2-user:ec2-user /opt/prometheus_$1/run_$1_httpserver.sh
        jmxport=17001
        export=`expr $jmxport + 10000`
        CONFIG_FILE="/opt/prometheus_$1/httpserver_$1_config.yml"
        SCRIPT_FILE="/opt/prometheus_$1/run_$1_httpserver.sh"

        echo "$CONFIG_FILE"

        echo "---" > $CONFIG_FILE
        echo "hostPort: localhost:$jmxport" >> $CONFIG_FILE
        echo "username: " >> $CONFIG_FILE
        echo "password: " >> $CONFIG_FILE
        echo " " >> $CONFIG_FILE
        echo "rules:" >> $CONFIG_FILE
        echo "- pattern: \".*\"" >> $CONFIG_FILE
        echo " " >> $CONFIG_FILE
        cat $CONFIG_FILE

        echo $SCRIPT_FILE

        echo "java -jar /opt/prometheus_$1/jmx_prometheus_httpserver/target/jmx_prometheus_httpserver-0.3.2-SNAPSHOT-jar-with-dependencies.jar $export $CONFIG_FILE" > $SCRIPT_FILE
        cat $SCRIPT_FILE
	

	echo "Starting the service"
	$SCRIPT_FILE &
	echo "Testing: curl http://localhost:$export/metrics"
else 
        echo "App $1 is not installed"
fi

