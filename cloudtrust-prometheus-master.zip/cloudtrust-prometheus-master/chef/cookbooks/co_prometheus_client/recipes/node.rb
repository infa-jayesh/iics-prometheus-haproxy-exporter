#
# Cookbook:: co_prometheus_client
# Recipe:: node
#
# Copyright:: 2018, The Authors, All Rights Reserved.

node_exporter 'main' do
  ## Example override listen
  #web_listen_address "0.0.0.0:9200"
  ## Enabled collectors should be part of COLLECTOR_LIST in https://github.com/evilmartians/chef-prometheus-exporters/blob/master/resources/node.rb
  collectors_enabled %w[
    arp
    bcache
    bonding
    conntrack
    cpu
    diskstats
    edac
    entropy
    filefd
    filesystem
    hwmon
    infiniband
    ipvs
    loadavg
    mdadm
    meminfo
    netdev
    netstat
    nfs
    sockstat
    stat
    textfile
    time
    timex
    uname
    vmstat
    xfs
    zfs
  ]
end

