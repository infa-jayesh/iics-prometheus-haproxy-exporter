#
# Cookbook:: co_prometheus_client
# Recipe:: haproxy
#
# Copyright:: 2018, The Authors, All Rights Reserved.

unless node['prometheus_exporters']['haproxy']['disable']

  haproxy_exporter 'main' do
    web_listen_address node['prometheus_exporters']['haproxy']['web_listen_address']
    scrape_uri node['prometheus_exporters']['haproxy']['scrape_uri']
    config_file "/opt/haproxy_exporter-#{node['prometheus_exporters']['haproxy']['version']}.linux-amd64/haproxy.yml"
    timeout_offset node['prometheus_exporters']['haproxy']['timeout_offset']
    log_level node['prometheus_exporters']['haproxy']['log_level']

    action %i[install enable start]
  end
end

