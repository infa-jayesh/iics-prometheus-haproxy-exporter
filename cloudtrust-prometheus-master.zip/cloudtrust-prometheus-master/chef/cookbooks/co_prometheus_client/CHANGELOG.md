# co_prometheus_client CHANGELOG

This file is used to list changes made in each version of the co_prometheus_client cookbook.

# 0.1.0

Initial release.

- change 0
- change 1

