name 'co_prometheus_client'
maintainer 'Cloudtrust Ops'
maintainer_email 'dlcloudtrustops@informatica.com'
license 'All Rights Reserved'
description 'Installs/Configures co_prometheus_client'
long_description 'Installs/Configures co_prometheus_client'
version IO.read(File.join(File.dirname(__FILE__), 'VERSION')) rescue `git describe --exact-match --tags $(git log -n1 --pretty='%h')`
chef_version '>= 12.14' if respond_to?(:chef_version)

depends 'prometheus_exporters', '= 0.8.2'

