# To learn more about Custom Resources, see https://docs.chef.io/custom_resources.html

resource_name :haproxy_exporter

property :web_listen_address, String, default: '0.0.0.0:9101'
property :scrape_uri, String, default: 'http://localhost:5000/baz?stats;csv'
property :config_file, String, default: "/opt/haproxy_exporter-#{node['prometheus_exporters']['haproxy']['version']}.linux-amd64/haproxy.yml"
property :timeout_offset, String, default: '0.5'
property :log_level, String, default: 'info'
property :user, String, default: 'root'

action :install do
  # Set property that can be queried with Chef search
  node.default['prometheus_exporters']['haproxy']['enabled'] = false

  options = "--haproxy.scrape-uri=#{new_resource.scrape_uri}"
  options += " --web.listen-address=#{new_resource.web_listen_address}"
  options += " --no-haproxy.ssl-verify" if #{new_resource.ssl_verify}

  service_name = "haproxy_exporter_#{new_resource.name}"
  prometheus_user = new_resource.respond_to?(:user) ? new_resource.user : 'root'

  # Download binary
  remote_file 'haproxy_exporter' do
    path "#{Chef::Config[:file_cache_path]}/haproxy_exporter.tar.gz"
    owner 'root'
    group 'root'
    mode '0644'
    source node['prometheus_exporters']['haproxy']['url']
    checksum node['prometheus_exporters']['haproxy']['checksum']
    notifies :restart, "service[#{service_name}]"
  end

  bash 'untar haproxy_exporter' do
    code "tar -xzf #{Chef::Config[:file_cache_path]}/haproxy_exporter.tar.gz -C /opt"
    action :nothing
    subscribes :run, 'remote_file[haproxy_exporter]', :immediately
  end

  link '/usr/local/sbin/haproxy_exporter' do
    to "/opt/haproxy_exporter-#{node['prometheus_exporters']['haproxy']['version']}.linux-amd64/haproxy_exporter"
  end

  service service_name do
    action :nothing
  end

  case node['init_package']
  when /init/
    %w[
      /var/run/prometheus
      /var/log/prometheus
    ].each do |dir|
      directory dir do
        owner 'root'
        group 'root'
        mode '0755'
        recursive true
        action :create
      end
    end

    directory "/var/log/prometheus/#{service_name}" do
      owner prometheus_user
      group 'root'
      mode '0644'
      action :create
    end

    template "/etc/init.d/#{service_name}" do
      cookbook 'prometheus_exporters'
      source 'initscript.erb'
      owner 'root'
      group 'root'
      mode '0755'
      variables(
        name: service_name,
        user: prometheus_user,
        cmd: "/usr/local/sbin/haproxy_exporter #{options}",
        service_description: 'Prometheus Haproxy Exporter',
      )
      notifies :restart, "service[#{service_name}]"
    end
  when /systemd/
    systemd_unit "#{service_name}.service" do
      content(
        'Unit' => {
          'Description' => 'Systemd unit for Prometheus Haproxy Exporter',
          'After' => 'network.target remote-fs.target apiserver.service',
        },
        'Service' => {
          'Type' => 'simple',
          'User' => 'root',
          'ExecStart' => "/usr/local/sbin/haproxy_exporter #{options}",
          'WorkingDirectory' => '/',
          'Restart' => 'on-failure',
          'RestartSec' => '30s',
        },
        'Install' => {
          'WantedBy' => 'multi-user.target',
        },
      )
      notifies :restart, "service[#{service_name}]"
      action :create
    end
  when /upstart/
    template "/etc/init/#{service_name}.conf" do
      cookbook 'prometheus_exporters'
      source 'upstart.conf.erb'
      owner 'root'
      group 'root'
      mode '0644'
      variables(
        env: environment_list,
        user: prometheus_user,
        cmd: "/usr/local/sbin/haproxy_exporter #{options}",
        service_description: 'Prometheus Haproxy Exporter',
      )
      notifies :restart, "service[#{service_name}]"
    end

  else
    raise "Init system '#{node['init_package']}' is not supported by the 'prometheus_exporters' cookbook"
  end
end

action :enable do
  action_install
  service "haproxy_exporter_#{new_resource.name}" do
    action :enable
  end
end

action :start do
  service "haproxy_exporter_#{new_resource.name}" do
    action :start
  end
end

action :disable do
  service "haproxy_exporter_#{new_resource.name}" do
    action :disable
  end
end

action :stop do
  service "haproxy_exporter_#{new_resource.name}" do
    action :stop
  end
end


