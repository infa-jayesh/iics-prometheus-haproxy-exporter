# # encoding: utf-8

# Inspec test for recipe co_prometheus_client::haproxy

# The Inspec reference, with examples and extensive documentation, can be
# found at http://inspec.io/docs/reference/resources/

os_name = os.name
os_release = os.release.to_f

# Node exporter
[9101].each do |haproxy_exporter_port|
  describe port(haproxy_exporter_port) do
    it { should be_listening }
    its('processes') { should cmp(/^haproxy_expo/) }
  end
end



