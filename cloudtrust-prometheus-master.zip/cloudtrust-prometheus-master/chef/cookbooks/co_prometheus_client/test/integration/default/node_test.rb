# # encoding: utf-8

# Inspec test for recipe co_prometheus_client::node

# The Inspec reference, with examples and extensive documentation, can be
# found at http://inspec.io/docs/reference/resources/

os_name = os.name
os_release = os.release.to_f

# Node exporter
[9100].each do |node_exporter_port|
  describe port(node_exporter_port) do
    it { should be_listening }
    its('processes') { should cmp(/^node_expo/) }
  end
end


