#!/bin/bash
#
# TODO: Add description of check
# TODO: Parameterize script with getopts
#

# SOCKS5 proxy url and port eg. PROXY=10.2.77.247:1080
PROXY=PROXY_HOST:IP

# Qualys endpoint url which returns 200
QUALYS_ENDPOINT_URL=https://qualysguard.qg2.apps.qualys.com/qglogin/index.html

STATUS=$(curl --silent --output /dev/null --connect-timeout 5 --write-out %{http_code} --socks5 $PROXY $QUALYS_ENDPOINT_URL)

if [ $STATUS -eq 200 ]; then
  echo "SERVICE OK"
  exit 0
else
  echo "WARNING: SOC5 proxy \"$PROXY\" has problem! Check whitelisted IP in /etc/opt/ss5/ss5.conf matches to $QUALYS_ENDPOINT_URL"
  exit 1
fi

