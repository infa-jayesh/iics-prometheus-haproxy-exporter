#!/bin/bash
#
# TODO: Add description 
#

tail -f /var/log/messages | grep --color=auto "consul\." 1>test.txt &
pid=`echo $!`
pkill -sigusr1 consul
sleep 1
kill $pid

python parse_consul.py
