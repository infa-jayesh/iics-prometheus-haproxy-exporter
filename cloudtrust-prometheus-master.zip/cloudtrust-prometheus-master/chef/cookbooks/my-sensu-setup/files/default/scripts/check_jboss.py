#!/usr/bin/python
#
# A JBossAS 7.1.1-Final Sensu check script
#
#
# Main Author
#   - Sunny Saurabh <ssaurabh@informatica.com>
# Version: 1.0
#
# USAGE--
#jboss_status -h
# It checks wether jboss server is running or not 
#

import sys
import json
import optparse
import requests
from requests.auth import HTTPDigestAuth


def exit_with_general_critical(e):
        if isinstance(e, SystemExit):
            return e
        elif isinstance(e, ValueError):
            print "CRITICAL - JbossAS Value Error:", e
            sys.exit(2)
        else:
            print "CRITICAL - General JbossAS Error:", e
    	sys.exit(2)
        return 2


def base_url(host, port):
    """
    Return the base URL for HTTP Management API
    
    :param host: JBossAS hostname
    :param port: JBossAS HTTP Management Port
    """

        url = "http://{host}:{port}/management/".format(host=host, port=port)
        return url


def server_status(host, port, user, password):
    """
    Return the JBoss server status
    
    :param host: JBossAS hostname
    :param port: JBossAS HTTP Management Port
    :param user: JBossAS management user name
    :param password: JBossAS management user password

    """
    try:
    	payload = '{"operation":"read-attribute","name":"server-state","json.pretty":1}'
    	url = base_url(host, port)
    	headers = {'Content-type': 'application/json'}


    	res = requests.post(url, data=payload, headers=headers, auth=HTTPDigestAuth(user, password))
    
    	return res.json()['result']

    except Exception, e:
            return exit_with_general_critical(e)


def main(argv):
    p = optparse.OptionParser(conflict_handler="resolve", description="This Sensu plugin checks the health of JBoss server.")

        p.add_option('-H', '--host', action='store', type='string', dest='host', default='127.0.0.1', help='The hostname you want to connect to')
        p.add_option('-P', '--port', action='store', type='int', dest='port', default=9990, help='The port JBoss management console is runnung on')
        p.add_option('-u', '--user', action='store', type='string', dest='user', default=None, help='The username you want to login as')
        p.add_option('-p', '--pass', action='store', type='string', dest='passwd', default=None, help='The password you want to use for that user')

    options, arguments = p.parse_args()
        host = options.host
        port = options.port
        user = options.user
        passwd = options.passwd

    return server_status(host, port, user, passwd)



if __name__ == '__main__':
        sys.exit(main(sys.argv[1:]))
