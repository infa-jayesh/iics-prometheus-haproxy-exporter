#!/usr/bin/python

####----------------------------------------####
## This script calculates percentage use      ##
## of disks.                                  ##
#### ---------------------------------------####
## Use: $./getDiskUsage.py "location"         ##
## client1.disk.usage 38.24 1497017590        ##
#### ---------------------------------------####
## 0 --> OK, Usage <  60%                     ##
## 1 --> WARNING, Usage < 70%                 ##
## 2 --> CRITICAL, Usage > 70%                ##
## 3 --> Somethig unexpected like different os##
####--------------------------------------  ####


from __future__ import division
import os
import sys
import time
from collections import namedtuple

__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"


#_ntuple_diskusage = namedtuple('usage', 'total used free')

def disk_usage(path):
    """
    Return disk usage statistics about the given path.
    Returned valus is a named tuple with attributes 'total', 'used' and
    'free', which are the amount of total, used and free space, in bytes.
    """
    try:
        for args in path:
            st = os.statvfs(args)
            free = st.f_bavail * st.f_frsize
            total = st.f_blocks * st.f_frsize
            used = (st.f_blocks - st.f_bfree) * st.f_frsize
            #_ntuple_diskusage(total, used, free)

            percentageUsgae = round((used / total) * 100, 2)

            if percentageUsgae <= 60.00:
                print("client1.disk.usage %.2f %d" % (percentageUsgae, int(time.time())))
                return 0
            elif percentageUsgae > 60.00 and percentageUsgae <= 70.00:
                print("client1.disk.usage %.2f %d" % (percentageUsgae, int(time.time())))
                return 1
            elif percentageUsgae > 70.00:
                print("client1.disk.usage %.2f %d" % (percentageUsgae, int(time.time())))
                return 2
            else:
                print("Unkonwn Error")
                return 3

    except Exception, e:
        print "CRITICAL - Internal Error:", e
        sys.exit(2)


if __name__ == '__main__':
    sys.exit(disk_usage(sys.argv[1:2]))
