#!/bin/bash
#  This check finds the first network device in use as a gateway and looks for errors or dropped packets.
#  it then checks against the delta saved file
#  If the delta of those reading is greater than a specific value then a warning is issued
#
# default is warning at 1 errors critical at 10.
# usage described in below function

function usage
{
echo "Usage: $0 options"
echo 'options'
echo 'h | --help'
echo 'c # | --critical=#'
echo 'w # | --warning=#'
exit 1
}

OPTS=`getopt -o hc:w: --long help,critical:,warning: -n 'parse-options' -- "$@"`
if [ $? != 0 ]; then
  echo "Option parse error." >&2;
  usage;
fi
eval set -- "$OPTS" > /dev/null 2>&1

HELP=false
CRITICAL=10
WARNING=1
AGE=350
OUT=/dev/shm/xerror

while true; do
  case "$1" in
    -h | --help )
      HELP=true
      shift
      ;;
    -c | --critical )
      CRITICAL="$2"
      shift 2
      ;;
    -w | --warning )
      WARNING="$2"
      shift 2
      ;;
    -- )
      shift
      break
      ;;
    *)
      break
      ;;
  esac
done

retVal=0

mydev=`route -n | grep UG | grep UG | awk '{ print $NF }' | sort | uniq | head -n 1`
xerror=`/sbin/ip -s link | grep -A5  $mydev | egrep -v '[a-z]'  | awk '{ print $3}' | head -n 1`
xdropped=`/sbin/ip -s link | grep -A5  $mydev | egrep -v '[a-z]'  | awk '{ print $4}' | tail -n 1`

if [ -e $OUT ]; then
  xtime=`stat -c '%Y' $OUT`
  xnow=`date +%s`
  xdiff=$(( xnow - xtime ))
  if [ $xdiff -lt $AGE ]; then
    perror=`cat $OUT | awk '{ print $1}'`
    pdropped=`cat $OUT | awk '{ print $2}'`
    xval=$(( (xerror - perror) + (xdropped - pdropped) ))
    if [ $xval -eq 0 ]; then
      retVal=0
      echo "OK - No network errors"
    elif [ $xval -gt $CRITICAL ]; then
      retVal=2
      echo "CRITICAL - check for errors in '/sbin/ip -s link | grep -A5  $mydev'"
    fi
  else
    echo "$OUT is older than $AGE seconds, make sure \$AGE is bigger than sensu check interval"
  fi
fi

echo "$xerror $xdropped" > $OUT
if [ $? -ne 0 ]; then
  retVal=2
  echo "CRITICAL - Error in executing 'echo "$xerror $xdropped" > $OUT'" 
fi

exit $retVal

