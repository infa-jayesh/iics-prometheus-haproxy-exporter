#!/bin/bash
#
# TODO: Add description of check
#

#only checks for consul endpoint if in docker
docker(){
  echo docker
  haproxy=`curl http://consul/v1/operator/autopilot/health`
  if [ `echo $haproxy | jq -r .Healthy` == true ]; then exit 0; else exit 2; fi
}

#checks for consul and local endpoints if not in docker
not_docker(){
  lhealthy=1
  haphealthy=1
  echo not_docker
  haproxy=`curl http://consul/v1/operator/autopilot/health`
  if [ `echo $haproxy | jq -r .Healthy` == true ]; then haphealthy=0; fi
  lhost=`curl http://localhost:8500/v1/operator/autopilot/health`
  if [ `echo $lhost | jq -r .Healthy` ]; then lhealthy=0; fi
  exit $(( $haphealthy + $lhealthy ))
}

#reads thru processes to find if we are in docker
awk -F/  == docker /proc/self/cgroup | read
NOT_DOCKER=`echo $?`
if [ $NOT_DOCKER == 0 ]; then docker; else not_docker; fi
