#!/bin/sh

HOSTNAME=`hostname`

function Echo()
{
    echo $HOSTNAME.$1 $2 `date +%s`
}

if [[ ! -z $(curl -s --max-time 2 http://169.254.169.254/latest/meta-data/ami-id) ]]; then 
  HOSTNAME=`hostname`
  MAC=`curl --silent http://169.254.169.254/latest/meta-data/mac`
  Echo instance_type `curl --silent http://169.254.169.254/latest/meta-data/instance-type`
  Echo instance_id `curl --silent http://169.254.169.254/latest/meta-data/instance-id`
  Echo iam_roles `curl --silent http://169.254.169.254/latest/meta-data/iam/info | jq -c .`
  Echo security_groups `curl --silent http://169.254.169.254/latest/meta-data/security-groups`
  Echo product_codes `curl --silent http://169.254.169.254/latest/meta-data/product-codes`
  Echo vpc-id `curl --silent http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MAC/vpc-id`
  Echo subnet-id `curl --silent http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MAC/subnet-id`
fi

