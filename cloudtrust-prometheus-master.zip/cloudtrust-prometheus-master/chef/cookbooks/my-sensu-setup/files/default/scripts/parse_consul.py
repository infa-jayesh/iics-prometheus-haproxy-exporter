#!/usr/bin/python
#
# TODO: Add description
#

import re, requests, json
req = requests.get('http://localhost:8500/v1/operator/autopilot/health')
js = req.json()
consul = open("test.txt","r")
res = dict()
for line in consul:
    data = line.split("\'consul.")[-1]
    try:
        data = data.split("\': ")
        res[data[0]] = data[1]
        data_result = data[1]
        form = data_result.split(' LastUpdated: ')
        data_result = form[0]
        data_result = re.sub("(?<!:) ",", ",str(data_result))
        data_result = re.sub(":","\":",data_result)
        data_result = re.sub(",","\",",data_result)
        data_result = re.sub(" "," \"",data_result)
        ti = re.sub("\n","",form[1])
        try:
            data_result = json.loads("{\""+data_result+"\"}")
            data_result['LastUpdated'] = ti
        except Exception as e:
            print data_result
            pass
        res[data[0]] = data_result
    except Exception as e:
        pass
res['autopilot_health'] = js
print json.dumps(res,sort_keys=True,indent=4, separators=(',', ': '))
