#!/usr/bin/env python

####------------------------------------------####
## This script checks if passed service is      ##
## running or not. It also checks if its        ##
## enabled or disabled                          ##
#### -----------------------------------------####
## Use: $./serviceAditd.py                      ##
## client1.auditd.status 0 1498625266           ##
#### -----------------------------------------####
## 0 --> running, enabled and logs are in limit ##
## 1 --> running, disabled but logs are in limit##
## 2 --> not running or logs are not in limit   ##
## 3 --> Somethig unexpected like different os  ##
####------------------------------------------####

from __future__ import division
import re
import os
import sys
import time
from subprocess import Popen, PIPE

__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"


def checkAuditSize():
    '''
    This function reads the aditd conf file and gets the location and default size of the audit logs.
    After it gets the location of the audit log file, it checks the size of the log file.
    In the end based on the size comparison (actual and defined size), it returns true or false.
    '''

    fileSize = 0
    definedSize = 0
    try:
        auditConf = open('/etc/audit/auditd.conf', 'r')
        for line in auditConf.read().split('\n'):
            if line.startswith('log_file'):
                logFile = re.search(r'= (.+?)$', line).group(1)
                fileSize = os.stat(logFile).st_size
                fileSize = round((fileSize / (1024 * 1024)), 2)
            elif line.startswith('max_log_file '):
                definedSize = re.search(r'= (.+?)$', line).group(1)
            else:
                pass

        if fileSize <= round(float(definedSize), 2):
            return True
        else:
            return False

    except Exception, e:
        print "CRITICAL3 - File Error:", e
        sys.exit(3)


def check_service_status(service):
    '''
    This function receives the 'auditd' as parameter.
    First it compares the size of actual log and defined sieze for the log.
    For this it calls the function checkAuditSize.
    If the actual size is less then defined size, then it checks the status of
    the service. Based on the status of the service, it gives output.
    '''
    try:
        boolSize = checkAuditSize()
        hostname = os.uname()[1]
        executed = 0
        out = ""
        err = ""

        if boolSize is False:
            print("%s.%s.status %d %d" % (hostname, service, 2, int(time.time())))
            return 2
        else:
            try:
                systemctl_res = Popen(['sudo', 'systemctl', 'status', service], stdout=PIPE, stderr=PIPE)
                out, err = systemctl_res.communicate()
                systemctl_res.stdout.close()
            except Exception, e:
                executed = 1
            if executed == 1 or 'systemctl: command not found' in err:
                try:
                    service_res = Popen(['sudo', 'service', service, 'status'], stdout=PIPE, stderr=PIPE)
                    out, err = service_res.communicate()
                    service_res.stdout.close()
                except Exception, e:
                    print "CRITICAL1 - Internal Error:", e
                    sys.exit(3) 

            if (('active (exited)' in out or 'active (running)' in out) or ('is running' in out)):
                print("%s is installed, started and enabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 0, int(time.time())))
                return 0
            elif ('active (exited)' in out or 'active (running)' in out) and service+'.service; disabled;' in out:
                print("%s is installed and started but disabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 1, int(time.time())))
                return 1
            elif ((('active (exited)' not in out) or ('active (running)' not in out)) and (('inactive (dead)' in out) or ('is stopped' in out) or ('is not running' in out))):
                print("%s : is installed but stopped." % (service))
                print("%s.%s.status %d %d" % (hostname, service, 2, int(time.time())))
                return 2
            elif ('could not be found' in err or 'unrecognized service' in err) and out == "":
                print("%s : Service not Found(or not installed)" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 3, int(time.time())))
                return 3
            else:
                print("%s : Unexpected Error" % (service))
                return 3

    except Exception, e:
        print "CRITICAL2 - Internal Error:", e
        sys.exit(3)


def main(args):
    try:
        for arg in args:
            return(check_service_status(arg))

    except Exception, e:
        print "CRITICAL1 - Internal Error:", e
        sys.exit(3)

if __name__ == '__main__':
    sys.exit(main(['auditd']))
