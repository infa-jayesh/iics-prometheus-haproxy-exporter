#!/usr/bin/env python

####----------------------------------------
## This script checks the offset time between
## local server and the server provided in
## argument.
#### ---------------------------------------
## Use: $./check_ntp.py -w 30 -c 80 -s '0.amazon.pool.ntp.org'
## OK - System clock is -93.844438076 seconds off.
#### ---------------------------------------

import sys
import argparse
from time import ctime

try:
    import ntplib
except ImportError:
    print("ImportError - %s - install it with 'pip install ntplib'" % sys.exc_info()[1])
    sys.exit(3)


def calculateOffset(server):
    '''
    This function receives remote server as parameter with which offset time will be
    calculated for local server. This function uses ntplin library to calcuate the
    offset.
    '''
    try:
       c = ntplib.NTPClient()
       response = c.request(server, version=3)
       return response.offset

    except Exception, e:
        print "CRITICAL - Offset calculation Error:", e
        sys.exit(2)


def check_offset_time(server, warning, critical):
    '''
    This function checks the value of the offset time and create alert accordingly.
    '''
    try:       
        offsetTime = calculateOffset(server)
        if  0 <= abs(offsetTime) <= abs(warning):
            print('OK - System clock is %0.2f seconds off.' % float(offsetTime))
            return 0
        elif (abs(warning) < abs(offsetTime) <= abs(critical)):
            print('WARNING - System clock is %0.2f seconds off.' % float(offsetTime))
            return 1
        elif abs(offsetTime) > abs(critical):
            print('CRITICAL - System clock is %0.2f seconds off.' % float(offsetTime))
            return 2
        else:
            print("%s : Unexpected Error" % (server))
            return 3

    except Exception, e:
        print("CRITICAL - Internal Error: %s", e)
        sys.exit(3)


def main(args):
    parser=argparse.ArgumentParser()

    parser.add_argument('--warning', '-w', '-W', help='Offset limit for warning, defaults to 60 seconds.', default=60, type=int)
    parser.add_argument('--critical', '-c', '-C',  help='Offset limit for critical, defaults to 120 seconds.', default=120, type=int)
    parser.add_argument('--server', '-s', '-S', help='ntp server, default is pool.ntp.org', default='pool.ntp.org')


    args=parser.parse_args()

    try:
        if args.warning <= args.critical:
            return(check_offset_time(args.server, float(args.warning), float(args.critical)))
        else:
            print("Unexpected Error: warning(defaults to 60 seconds) should be less or equal to critical. Please define warning properly")
            sys.exit(3)

    except Exception, e:
        print("CRITICAL - ArgumentParse Error: %s", e)
        sys.exit(2)


if __name__ == '__main__':
    args = sys.argv[1:]
    sys.exit(main(args))
