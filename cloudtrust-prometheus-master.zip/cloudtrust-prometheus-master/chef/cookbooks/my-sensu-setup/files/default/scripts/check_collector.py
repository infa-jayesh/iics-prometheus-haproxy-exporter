#!/usr/bin/python

####----------------------------------------####
## This script checks if passed service is    ##
## running or not. It also checks if its      ##
## enabled or disabled                        ##
#### ---------------------------------------####
## Use: $./checkCollector.py status           ##
## client1.sumoCollector.status 0 1497051560  ##
#### ---------------------------------------####
## 0 --> collector running and api working    ##
## 1 --> collector running but api failing    ##
## 2 --> collector not running                ##
## 3 --> Somethig unexpected like different os##
####--------------------------------------  ####

import sys
import time
from subprocess import Popen, PIPE
try:
    import requests
except Exception, e:
    print "CRITICAL - Import Error:", e
        sys.exit(2)


__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"

key_id = SUMO_KEY_ID 
secret_key = SUMO_SECRET_KEY 

def check_service_status(action):
    '''
    This function gets action like status as parameter from main function.
    It checks the sumo collector runnig status, which uses the sumo collector
    script. It also checks even if collector is runnig whether API is running
    successfully.
    '''

    header = {'content-type': 'application/json', 'accept': 'application/json'}
    key = (key_id, secret_key)
    try:
        service_res = Popen(['sh', '/opt/SumoCollector/collector', action], stdout=PIPE, stderr=PIPE)
        out, err = service_res.communicate()

        if action == 'start' or action == 'stop':
            pass
        elif action == 'status':
        
            if err == ''  and out != '':
                if 'SumoLogic Collector is not running.' in out:
                    print("client1.sumoCollector.status %d %d" % (2, int(time.time())))
                    return 2
                elif 'SumoLogic Collector is running: PID:' in out:
                    respons = requests.get('https://api.us2.sumologic.com/api/v1/collectors?limit=10', headers=header, auth=key)
                    if isinstance(respons.json(), dict) and 'collectors' in respons.json():
                        print("client1.sumoCollector.status %d %d" % (0, int(time.time())))
                        return 0
                    else:
                        print("client1.sumoCollector.status %d %d" % (1, int(time.time())))
                        return 1
            elif err != ''  and out == '':
                print("Unexpected %s" % err)
                sys.exit(3)
        else:
            print("Unexpected argument: %s" % action)
            sys.exit(3)

        service_res.stdout.close()

    except Exception, e:
        print "CRITICAL - Internal Error:", e
            sys.exit(2)


def main(args):
    try:
        for arg in args:
            return(check_service_status(arg))

    except Exception, e:
        print "CRITICAL - Internal Error:", e
            sys.exit(2)

if __name__ == '__main__':
    args = sys.argv[1:2]
    sys.exit(main(args))
