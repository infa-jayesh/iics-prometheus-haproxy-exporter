#!/usr/bin/env python
#
# Check if Bit9 agent is connected and whether it's in Low or High enforcement mode
# 
# Returns:
#  0 --> Bit9 agent is connected and in high enforcement mode
#  1 --> Bit9 agent is connected and in low enforcement mode
#  2 --> All other states
#

import subprocess
import sys

def run_command(cmd):
    return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE).communicate()

def check_status():
    command = "/opt/bit9/bin/b9cli --status" # Bit9 status command for Linux Instances
    out = run_command(command)

    for line in out:
        if line.strip():
            if "Connection:        Connected" in line.strip(): # Check if Agent is connected
                if "Current:           Low" in line.strip(): # If agent is connected, check if its in Low
                    return 1
                if "Current:           High" in line.strip():# If agent is connected, check if its in High
                    return 0
            else:
                return 2 # All other condition are bad for us
if __name__ == "__main__":
    status = check_status()
    sys.exit(status)
