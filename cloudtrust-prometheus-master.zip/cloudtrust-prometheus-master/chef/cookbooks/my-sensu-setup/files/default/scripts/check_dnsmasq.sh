#!/usr/bin/bash
#
# Check if dnsmasq is running
#

if [[ `ps aux | awk '$11=="/usr/sbin/dnsmasq"'` ]]; then echo; else exit 2; fi

#check how long it takes to resolve our trusted host (google)
START=$(date +%s%N)
res=`host -t a google.com`
success=$?
END=$(date +%s%N)
DIFF=$((END - START))
test=`echo $res | grep host`
if [[ $DIFF -gt 10000000 ]]; then
    exit 1
elif [[ $success -gt 0 ]]; then
    exit 2
else
    exit 0
fi
