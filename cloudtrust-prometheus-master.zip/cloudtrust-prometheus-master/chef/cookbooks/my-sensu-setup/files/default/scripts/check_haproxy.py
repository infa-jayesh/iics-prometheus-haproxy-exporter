#!/usr/bin/python

####----------------------------------------####
## This script checks the count of registered ##
## servers in haproxy. If some server is      ##
## registered with haproxy as "web" then it   ##
## return the count of UP, DOWN and No Check  ##
#### ---------------------------------------####
## Use: $./get_count.py web                   ##
## Stat.web.UP : 0                            ##
## Stat.web.Down : 3                          ##
## Stat.web.No Check : 0                      ##
#### ---------------------------------------####
## UP --> Its number of up servers            ##
## DOWN --> Its number of DOWN servers        ##
## No Check --> It numer of server on which   ##
##              desired server is not running.##
####--------------------------------------  ####

import os
import sys
import time
from subprocess import Popen, PIPE, check_output, STDOUT, CalledProcessError

__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"


def get_count(proc_list):
    '''
    This function recives the process list for which we count the number from haproxy.
    This uses the stats from haproxy socket and also subprocess module from python.
    '''
    try:
        if os.path.exists("/var/run/haproxy.sock"):
            for proces in proc_list:
                echo_proc = Popen(["echo", "show stat"], stdout=PIPE)
                nc_proc = Popen(["nc", "-U", "/var/run/haproxy.sock"], stdin=echo_proc.stdout, stdout=PIPE)
                arg_proc = check_output(["grep", proces], stdin=nc_proc.stdout, stderr=STDOUT)
                proc_data = arg_proc.splitlines()
                UP = 0
                Down = 0
                No_Check = 0
                if proc_data:
                    for line in proc_data:
                        if "UP".upper() in line.upper():
                            UP = UP + 1
                        elif "DOWN".upper() in line.upper():
                            Down = Down + 1
                        elif "no check".upper() in line.upper():
                            No_Check = No_Check + 1
                        else:
                                print "This process doesn't exist"
                    sys.exit(2)

                print "Stat.%s.UP : %d" % (proces, UP)
                print "Stat.%s.Down : %d" % (proces, Down)
                print "Stat.%s.No Check : %d" % (proces, No_Check)
                sys.exit(0)

                # Don't use shell=True, as in below line, because it can cause ssl injection while taking argument.
                # count_stat = sbpopen("echo 'show stat' | nc -U /var/run/haproxy.sock | grep consul | grep UP | wc -l", shell=True,stdout=PIPE).communicate()[0]
        else:
            print("This is not a load balancer")
            sys.exit(3)

    except CalledProcessError:
        print "None"
        sys.exit(3)


if __name__ == "__main__":
    get_count(sys.argv[1:])
