#!/bin/bash
#
# call with a regex to uniquely find the process and optionally a port.
# if no port is passed we test the first open one
# TODO: Parameterize script with getopts
# example passed would be ./check_proc_port.sh 'nc.-lk'
yada=0

pid=`ps -ef | grep $1 2>&1| egrep -v grep | egrep -v $$ | awk '{ print $2}'`
npid=`echo pid | wc -l`
if [ $npid -lt 1 ]; then
    yada=$((yada +1))
else
  ports=`netstat -tulpvn | grep 19627 | grep LISTEN | grep  -w tcp | egrep -v tcp6 | sed 's/:/ /' | awk '{ print $5}' | head -n 1`
  nports=`echo ports | wc -l`
  if [ $nports -lt 1 ]; then
      yada=$((yada +1))
  fi
fi


if [ "a$2" == "a" ]; then
  nc  -v -w1 0.0.0.0 1999  >/dev/null 2>&1 < /dev/null
  if [ $? -ne 0 ]; then
    yada=$((yada +1))
  fi
fi

if [ $yada -gt 0 ]; then
  exit 1
else
  exit 0
fi

