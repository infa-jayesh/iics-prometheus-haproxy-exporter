#!/bin/bash
# This check queries the vault health endpoint. It exits with an exir code of 0 if
# vault is up and running as expected (initialized, unsealed and active), if vault is up
# but not running as expected, fails with exit code 1
# otherwise failse with exit code 2
#TODO: implement getopt to change whether response codes 429,501,503 are exit code 0 1 or 2

#get response code of health check
response=$(curl --write-out %{http_code} --silent --output /dev/null $VAULT_ADDR/v1/sys/health)
if [ $response == 200 ]; then exit 0;   #initialized, unsealed and active
elif [ $response == 429 ]; then exit 1; #unsealed and standby
elif [ $response == 501 ]; then exit 1; #not initialized
elif [ $response == 503 ]; then exit 1; #sealed
fi
exit 2 #other issue
