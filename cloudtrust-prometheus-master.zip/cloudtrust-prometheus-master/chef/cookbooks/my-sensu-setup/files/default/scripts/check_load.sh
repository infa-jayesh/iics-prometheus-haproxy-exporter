#!/bin/bash
#
#  This check finds the number of CPUs then divides load by that to figure out actual usage.
#  If load is > WARNING% then a warning is issued
#  If load is > CRITICAL% then a crit is issued
#  If the previous check is successful then the it looks for any individual core that is using more than ICRITICAL%
#  If true then it issues a crit

function usage
{
echo "Usage: $0 options"
echo 'options'
echo 'h | --help'
echo 'c # | --critical=#'
echo 'w # | --warning=#'
echo 'i # | --icritical=#'
exit 1
}

OPTS=`getopt -o hc:w:i: --long help,critical:,warning:icritical -n 'parse-options' -- "$@"`
if [ $? != 0 ]; then
  echo "Option parse error." >&2;
  usage;
fi
eval set -- "$OPTS" > /dev/null 2>&1

HELP=false
ICRITICAL=80
CRITICAL=60
WARNING=34

while true; do
  case "$1" in
    -h | --help )
      HELP=true
      shift
      ;;
    -c | --critical )
      CRITICAL="$2"
      shift 2
      ;;
    -w | --warning )
      WARNING="$2"
      shift 2
      ;;
    -i | --icritical )
      ICRITICAL="$2"
      shift 2
      ;;
    -- )
      shift
      break
      ;;
    *)
      break
      ;;
  esac
done


 


retVal=2
ncpus=`nproc`
realload=`cat /proc/loadavg  | awk '{printf "%3.0F\n", ($1 * 100)}'`
adjustedload=`echo $realload $ncpus | awk '{printf "%3.0F\n", ($1 / $2 )}'`

if [ $adjustedload -gt $CRITICAL ]; then 
  retVal=2
elif [ $adjustedload -gt $WARNING ]; then 
  retVal=1
else
  yada=0
  for i in `mpstat -P ALL | egrep -v "CPU" | egrep -v all | grep [0-9] | awk '{printf "%2.0F\n", $NF}'`
    do
      if [ $i -gt $ICRITICAL ]; then
        yada=$(( yada + 1 ))
      fi
    done
  if [ $yada -eq 0 ]; then 
    retVal=0
  fi
fi

exit $retVal
