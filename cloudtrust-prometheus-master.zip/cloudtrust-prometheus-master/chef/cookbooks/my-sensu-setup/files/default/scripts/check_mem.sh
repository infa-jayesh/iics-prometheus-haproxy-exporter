#!/bin/bash
#
# default is warning at 80% used critical at 90%.
# has the ability to determine free including file cache (pctFree)
# usage described in below function

function usage
{
echo "Usage: $0 options"
echo 'options'
echo 'h | --help'
echo 'c # | --critical=#'
echo 'w # | --warning=#'
exit 1
}

OPTS=`getopt -o hc:w: --long help,critical:,warning: -n 'parse-options' -- "$@"`
if [ $? != 0 ]; then
  echo "Option parse error." >&2;
  usage;
fi
eval set -- "$OPTS" > /dev/null 2>&1

HELP=false
CRITICAL=10
WARNING=20

while true; do
  case "$1" in
    -h | --help )
      HELP=true
      shift
      ;;
    -c | --critical )
      CRITICAL="$2"
      shift 2
      ;;
    -w | --warning )
      WARNING="$2"
      shift 2
      ;;
    -- )
      shift
      break
      ;;
    *)
      break
      ;;
  esac
done

retVal=2

MemTotal=`cat /proc/meminfo | grep MemTotal | awk '{ print $2 }'`
MemFree=`cat /proc/meminfo | grep MemFree | awk '{ print $2 }'`


grep Enterprise /etc/redhat-release > /dev/null 2>&1
if [ $? -eq 0 ]; then
  mver=`cat /etc/redhat-release | awk '{ print $7}' |  awk '{ printf "%1d\n",$1}'`
else
  mver=`cat /etc/redhat-release | awk '{ print $4}' |  awk '{ printf "%1d\n",$1}'`
fi

if [ $mver -eq 6 ]; then
  free -k | tee /tmp/memk.$$ | grep "Mem:" > /tmp/memavi.$$
  buffers=`cat /tmp/memavi.$$ | awk '{ print $6}'`
  cached=`cat /tmp/memavi.$$ | awk '{ print $7}'`
  free=`cat /tmp/memavi.$$ | awk '{ print $4}'`
  shared=`cat /tmp/memavi.$$ | awk '{ print $5}'`
  used=`cat /tmp/memavi.$$ | awk '{ print $3}'`
  MemFree=`grep 'buffers/cache' /tmp/memk.$$ | awk '{print $NF}'`

  u=$(( used + shared ))
  f=$(( buffers + cached + free ))
  #MemAvailable=$(( f - u ))
  MemAvailable=$(( MemTotal - u ))
else
  MemAvailable=`cat /proc/meminfo | grep MemAvailable | awk '{ print $2 }'`
fi

pctFree=`echo $MemAvailable $MemTotal | awk '{printf "%2.0F\n", ($1/$2)*100}'`
aFree=`echo $MemFree $MemTotal | awk '{printf "%2.0F\n", ($1/$2)*100}'`

if [ $aFree -lt $CRITICAL ]; then
  if [ $pctFree -ge $CRITICAL ]; then
    retVal=1
    echo "`basename $0` WARNING: Actual Free Memory ${aFree}% < ${CRITICAL}% and Total Memory Available ${pctFree}% >= ${CRITICAL}%" >&2
  fi
elif [ $aFree -lt $WARNING ]; then
  echo "`basename $0` WARNING: Actual Free Memory ${aFree}% < ${WARNING}%" >&2
  retVal=1
else
  retVal=0
fi

if [ $retVal -eq 2 ]; then
  echo "`basename $0` CRITICAL: Actual Free Memory = ${aFree}%; Total Memory Available = ${pctFree}%; Threshold = ${CRITICAL}%" >&2
fi

rm /tmp/memavi.$$ &>/dev/null

exit $retVal

