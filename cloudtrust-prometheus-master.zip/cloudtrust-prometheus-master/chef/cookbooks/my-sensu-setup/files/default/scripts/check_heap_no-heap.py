#!/usr/bin/python

#
# A JBossAS 7.1.1-Final Sensu check script
#
#
# Main Author
#   - Sunny Saurabh <ssaurabh@informatica.com>
# Version: 1.0
#
# USAGE--
#check_heap_no_heap.py -h
# It provides the percentage usage for heap memory or non-heap memory for jBoss 
#


import sys
import json
import time
import optparse
import requests
from requests.auth import HTTPDigestAuth

def base_url(host, port):
    """
    Provides base URL for HTTP Management API
    
    :param host: JBossAS hostname
    :param port: JBossAS HTTP Management Port
    """

    url = "http://{host}:{port}/management/".format(host=host, port=port)
    return url


def check_heap_no_heap(host, port, user, password, payload, heap_bool, mem_type):
    """
    Provides the heap memory details like max or used for heap or non-heap
    
    :param host: JBoss hostname
    :param port: JBoss HTTP Management Port
    :param user: JBoss management user
    :param password: JBoss management user password
    :param payload: payload for the HTTP API call
    :param heap_bool: Wether it is heap or non-heap
    :param mem_type: Whether it is max heap usage or used heap
    """

    try:
        heap_type = ''
        if heap_bool == True:
            heap_type = 'heap-memory-usage'
        elif heap_bool == False:
            heap_type = 'non-heap-memory-usage'
        else:
            sys.exit(2)

        url = base_url(host, port)
        headers = {'Content-type': 'application/json'}

        res = requests.post(url, data=payload, headers=headers, auth=HTTPDigestAuth(user, password))
        data = res.json()
        try:    
            outcome = data['outcome']
            if outcome == "failed":
                print "CRITICAL - Unexpected value : %s" % data
                sys.exit(2)
        except KeyError: pass

        return data['result'][heap_type][mem_type]

    except Exception, e:
        # The server could be down; make this CRITICAL.
        print "CRITICAL - JbossAS Error:", e
        sys.exit(2)


def check_heap_usage(host, port, user, passwd):
    """
    Provides the heap memory details like max or used for heap or non-heap
    
    :param host: JBoss hostname
    :param port: JBoss HTTP Management Port
    :param user: JBoss management user
    :param password: JBoss management user password
    """

    payload = '{"operation":"read-resource", "include-runtime":"true", "address":[{"core-service":"platform-mbean"},{"type":"memory"}], "json.pretty":1}'
    
    try:
        used_heap = check_heap_no_heap(host, port, user, passwd, payload, True, 'used')
        max_heap = check_heap_no_heap(host, port, user, passwd, payload, True, 'max')
        percent = round((float(used_heap * 100) / max_heap), 2)
        return percent 
    except Exception, e:
        return exit_with_general_critical(e)

def check_non_heap_usage(host, port, user, passwd):
    """
    Provides the heap memory details like max or used for heap or non-heap
    
    :param host: JBoss hostname
    :param port: JBoss HTTP Management Port
    :param user: JBoss management user
    :param password: JBoss management user password
    """

    payload = '{"operation":"read-resource", "include-runtime":"true", "address":[{"core-service":"platform-mbean"},{"type":"memory"}], "json.pretty":1}'
    
    try:
        used_heap = check_heap_no_heap(host, port, user, passwd, payload, False, 'used')
        max_heap = check_heap_no_heap(host, port, user, passwd, payload, False, 'max')
        percent = round((float(used_heap * 100) / max_heap), 2)
        return percent 

    except Exception, e:
        return exit_with_general_critical(e)


def nagios_output(percent_usage, action, warning, critical):
    """
    Provides the heap memory details like max or used for heap or non-heap
    
    :param percent_usage: Percent usage of heap or non-heap memory
    :param warning: WARNINIG limit for percentage usage
    :param critical: CRITICAL limit for percentage usage
    """

    if percent_usage > 0 and percent_usage <= warning:
        print("client1.jboss.%s %f %d" % (action, percent_usage, int(time.time())))
        sys.exit(0)
    elif percent_usage > warning and percent_usage <= critical:
        print("client1.jboss.%s %f %d" % (action, percent_usage, int(time.time())))
        sys.exit(1)
    elif percent_usage > critical:
        print("client1.jboss.%s %f %d" % (action, percent_usage, int(time.time())))
        sys.exit(2)
    else:
        print("Unexpected")
        sys.exit(3)


def main(argv):

    p = optparse.OptionParser(conflict_handler="resolve", description="This Sensu plugin checks the percentage heap/non-heap usage of JBossAS.It calculates percentage by :(used*100)/max ")

    p.add_option('-H', '--host', action='store', type='string', dest='host', default='127.0.0.1', help='The hostname you want to connect to')
    p.add_option('-P', '--port', action='store', type='int', dest='port', default=9990, help='The port JBoss management console is runnung on')
    p.add_option('-u', '--user', action='store', type='string', dest='user', default=None, help='The username you want to login as')
    p.add_option('-p', '--pass', action='store', type='string', dest='passwd', default=None, help='The password you want to use for that user')
    p.add_option('-A', '--action', action='store', type='choice', dest='action', default='heap_usage', help='The action you want to take', choices=['heap_usage', 'non_heap_usage'])
    p.add_option('-W', '--warning', action='store', dest='warning', default=None, help='The warning threshold we want to set')
    p.add_option('-C', '--critical', action='store', dest='critical', default=None, help='The critical threshold we want to set')


    options, arguments = p.parse_args()
    host = options.host
    port = options.port
    user = options.user
    passwd = options.passwd
    action = options.action
    warning = float(options.warning or 80)
    critical = float(options.critical or 90)


    if action == "heap_usage":
        return nagios_output(check_heap_usage(host, port, user, passwd), "heap_percent_usage", warning, critical)
    elif action == "non_heap_usage":
        return nagios_output(check_non_heap_usage(host, port, user, passwd), "non_heap_percent_usage", warning, critical)
    else:
        return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
