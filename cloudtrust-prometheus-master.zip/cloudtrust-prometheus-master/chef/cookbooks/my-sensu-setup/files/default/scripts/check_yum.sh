#!/bin/bash
#
#  This check looks for any updates available for the current OS
#  If it canot determine updates then this is considered a critical failure
#  If any updates are available then a warning is issued
#  The parameters are currently hard coded and need to be changed to defaults overridable via the command line
#  A help page also needs to be applied
#

retVal=2
ddiff=$(( 60 * 60 * 24 * 45 ))
ytime=`stat  --printf="%Z\n"  /var/log/yum.log 2>/dev/null`
if [ $? -gt 0 ]; then
  retVal=2
else
  now=`date +%s`
  delta=$(( now - ytime ))
  if [ $delta -gt $ddiff ]; then
    retVal=1
  else
    updates=`yum check-update --quiet | grep '^[a-Z0-9]' | wc -l`
    if [ $? -gt 0 ]; then
      retVal=2
    else
      if [ $updates -gt 0 ]; then 
        retVal=1
      else
        retVal=0
      fi
    fi
  fi
fi
exit $retVal
