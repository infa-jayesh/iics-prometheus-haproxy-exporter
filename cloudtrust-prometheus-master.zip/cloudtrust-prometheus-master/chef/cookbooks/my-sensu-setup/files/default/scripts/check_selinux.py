#!/usr/bin/python


####----------------------------------------####
## This script checks if seLinux is runnig    ##
## in 'permissive' mode. It also checks if    ##
## seLinux is running.
#### ---------------------------------------####
## Use: $./seLinuxMode.py                     ##
## client1.seLinux.mode 2 1497020695          ##
#### ---------------------------------------####
## 0 --> running and mode is permissive       ##
## 1 --> running and mode is not permissive   ##
## 2 --> not running and is disabled          ##
## 3 --> Somethig unexpected like different os##
####--------------------------------------  ####


import sys
import re
import time


__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"


def getSeLinuxMode():
    '''
    This function gets the seLinux mode and returns it to be be
    sensu metrics.
    '''
    try:
        with open("/etc/sysconfig/selinux", "r") as readFile:
            for line in readFile:
                li = line.strip()
                if not li.startswith('#'):
                    if re.search('\\bSELINUX\\b', li) is not None:
                        return li.split('=', 1)[1]

    except Exception, e:
        print "CRITICAL - Internal Error:", e
        sys.exit(2)


def checkSeLinuxMode(mode):
    '''
    This function compares the seLinux mode and accordingly
    set the sensu metrics.
    '''
    try:
        if mode == 'permissive':
            print("client1.seLinux.mode 0 %d" % (int(time.time())))
            return 0
        elif mode == 'enforcing':
            print("client1.seLinux.mode 1 %d" % (int(time.time())))
            return 1
        elif mode == 'disabled':
            print("client1.seLinux.mode 2 %d" % (int(time.time())))
            return 2
        else:
            print("Unkonwn Error")
            return 3

    except Exception, e:
        print "CRITICAL - Internal Error:", e
        sys.exit(2)

if __name__ == '__main__':
    sys.exit(checkSeLinuxMode(getSeLinuxMode()))
