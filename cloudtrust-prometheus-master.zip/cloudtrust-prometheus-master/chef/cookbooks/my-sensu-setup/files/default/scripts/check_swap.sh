#!/bin/bash
#
#  This check looks to see if swap has been defined and if so looks for activity. Activity is defined as swap in use over d seconds
#  If there is any activity then critical is issued
#  If there is no activity it checks to see if swap is being used
#  If more than 10% is in use it issues a warning
#  If more than 30% is in use it issues a crit
#

function usage
{
echo "Usage: $0 options"
echo 'options'
echo 'h | --help'
echo 'c # | --critical=#'
echo 'w # | --warning=#'
echo 'd # | --duration=#'
exit 1
}

OPTS=`getopt -o hc:w:d: --long help,critical:,warning,duration: -n 'parse-options' -- "$@"`
if [ $? != 0 ]; then
  echo "Option parse error." >&2;
  usage;
fi
eval set -- "$OPTS" > /dev/null 2>&1

HELP=false
CRITICAL=10
WARNING=30
DURATION=3

while true; do
  case "$1" in
    -h | --help )
      HELP=true
      shift
      ;;
    -c | --critical )
      CRITICAL="$2"
      shift 2
      ;;
    -w | --warning )
      WARNING="$2"
      shift 2
      ;;
    -d | --duration )
      DURATION="$2"
      shift 2
      ;;
    -- )
      shift
      break
      ;;
    *)
      break
      ;;
  esac
done

retVal=2
swap=`cat  /proc/swaps  | egrep -v Filename | wc -l`
if [ "a$swap" != "a" ]; then
  if [ $swap -gt 0 ]; then
    isactive=`vmstat 1 $DURATION  2>&1 | tail -n 3 | awk '{split($0,a," "); sum += a[7] ; sum += a[8]};  END {print sum}'`
    if [ $isactive -gt 0 ]; then
      retVal=2
    else
      tswap=`vmstat -s | grep  "total swap" | awk '{ print $1}'`
      uswap=`vmstat -s | grep  "used swap" | awk '{ print $1}'`
      if [ "a$uswap" == "a0" ]; then
        retVal=0
      else
        pctused=`echo "$tswap $uswap" | awk '{ printf "%2.0f\n", ($1+1/$2+1) * 100 }'`
        if [ $pctused -gt $CRITICAL ]; then
          retVal=2
        elif [ $pctused -gt $WARNING ]; then
          retVal=1
        else
          retVal=0
        fi
      fi
    fi
  fi
fi
exit $retVal

