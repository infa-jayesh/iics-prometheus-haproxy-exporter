#!/bin/python

####-------------------------------------------####
## This script checks if passed service is       ##
## running or not. It also checks if its         ##
## enabled or disabled                           ##
#### ------------------------------------------####
## Use: $python check_rsyslog.py                 ##
## client1.rsyslog.status 0 1498638388           ##
#### ------------------------------------------####
## 0 --> running, enabled and backup is correct  ##
## 1 --> running, disabled but backup not correct##
## 2 --> not running or backups are not correct  ##
## 3 --> Somethig unexpected like different os   ##
####-------------------------------------------####

from __future__ import division
import re
import os
import sys
import glob
import time
from subprocess import Popen, PIPE



__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"


def checkRsysLog():
  '''
  This function reads the logrotated conf file and gets the location logrotate log files.
  It also gets the default rotation frequency.
  Then it checks the number of logs present in /var/log/ for particular module like message.
  It return True if the number of present logs meets the given frequency else False
  '''

  rotateDuration = 0
  definedPath = 0
  try:
    rsysConf = open('/etc/logrotate.conf' , 'r')
    for line in rsysConf.read().split('\n'):
      if line.startswith('rotate'):
        rotateDuration = re.search(r' (.+?)$', line).group(1)
      elif line.startswith('include'):
        definedPath = re.search(r' (.+?)$', line).group(1)
      else:
        pass
    rsysConf.close()

    logRotateFiles = open(definedPath+'/syslog', 'r')
    logStatus = []
    for line in logRotateFiles.read().split('\n'):
      if line.startswith('/'):
        if len(glob.glob(line+'*')) == int(rotateDuration) + 1:
          logStatus.append(True)
        else:
          logStatus.append(False)

    return logStatus
    
  except Exception, e:
    print "CRITICAL - File Error:", e
    sys.exit(3)

def check_service_status(service):
  '''
  This function receives the 'rsyslog' as parameter.
  Then based on the value, True/False returned by same, it checks the status of the rsyslog service.
  Based on the output, it print the status.
  '''
  try:
    logStatus= checkRsysLog()

    if False in logStatus:
      print("client1.%s.status %d %d" % (service, 2, int(time.time())))
      return 2
    else:
      service_res = Popen(['systemctl', 'status', service], stdout=PIPE, stderr=PIPE)
      out, err = service_res.communicate()

      if ('active (exited)' in out or 'active (running)' in out) and service+'.service; enabled;' in out:
        print("client1.%s.status %d %d" % (service, 0, int(time.time())))
        return 0
      elif ('active (exited)' in out or 'active (running)' in out) and service+'.service; disabled;' in out:
        print("client1.%s.status %d %d" % (service, 1, int(time.time())))
        return 1
      elif (('active (exited)' not in out and 'active (running)' not in out) or 'inactive (dead)' in out) and service+'.service; disabled;' in out:
        print("client1.%s.status %d %d" % (service, 2, int(time.time())))
        return 2
      else:
        print("Unexpected Error")
        return 3

    service_res.stdout.close()

  except Exception, e:
    print "CRITICAL - Internal Error:", e
    sys.exit(3)


def main(args):
  try:
    for arg in args:
      return(check_service_status(arg))

  except Exception, e:
    print "CRITICAL - Internal Error:", e
    sys.exit(3)

if __name__ == '__main__':
  sys.exit(main(['rsyslog']))