#!/usr/bin/python

####----------------------------------------#### 
## This script checks is a sensu metrics. It  ##
## checks if sumo is being populated with logs##
## or not.                                    ##
#### ---------------------------------------#### 
## Use: $./sumo_log_jobs.py                   ## 
## sourceCategory.log.status 0 1497003000     ## 
## sourceCategory.log.status 2 1497003000     ## 
## Stat.web.No Check : 0                      ## 
#### ---------------------------------------#### 
## 0 --> logs generated with in 5 minutes     ## 
## 1 --> nologs <5 miutes, 5 < logs < 10 min  ## 
## 2 --> nologs > 10                          ## 
## 3 --> Somethig unexpected like sumo down  .## 
####--------------------------------------  #### 



import sys
import time
import json
import datetime
from pprint import pprint

try:
    import requests
except Exception, e:
    print "CRITICAL - Import Error:", e
        sys.exit(2)

__author__ = "Sunny Saurabh"
__email__ = "ssaurabh@informatica.com"

key_id = SUMO_KEY_ID
secret_key = SUMO_SECRET_KEY


def getBeforeTime(nowTime, minutesBefore):
    '''
    This calculates the time in a required format, before passed minutes
    '''
    tm = nowTime - datetime.timedelta(minutes=minutesBefore)
    return tm.strftime("%Y-%m-%dT%H:%M:%S")
    

def getSearchResponse(fromTime, toTime):
    '''
    This function accepts start and end time and make Sumo API call to get the jobs details
    between start time and end time. There are two API calls: 1st call is post to create search jobs.
    Second call gets the details from the search jobs, which was created in 1st API call.
    '''
    try:
        URL = "https://api.us2.sumologic.com/api/v1/search/jobs"
        #payload = {'query' : '| count _sourceCategory', 'from': fromTime, 'to' : toTime, 'timeZone': 'UTC'}
        payload = {'query' : '| count _messagetime', 'from': fromTime, 'to' : toTime, 'timeZone': 'UTC'}
        header = {'content-type': 'application/json', 'accept': 'application/json'}

        res = requests.post(URL, auth=(key_id, secret_key), data=json.dumps(payload), headers=header)

        NEW_URL = URL+ "/" + res.json()['id']

        resp = requests.get(NEW_URL, headers=header, auth=(key_id, secret_key), cookies= res.cookies)

        if resp.json()['messageCount'] <= 0:
            return False
        else:
            return True
    except Exception, e:
        print "CRITICAL - Sumo API Error:", e
            sys.exit(2)



def main():
    '''
    This main function calculates times for 5 and 10 minutes before current time.
    So that we can calculates logs for those 0-5 and 5-10 minutes. The we pass these
    time to get the Sumo API to get the logs/jobs. Based on the logs in Sumo, we
    publish Sensu metrics.
    '''
    try:
        now = datetime.datetime.now()

        nowTime = now.strftime("%Y-%m-%dT%H:%M:%S")
        before5Minutes = getBeforeTime(now, 5)
        before10Minutes = getBeforeTime(now, 10)

        logIn5min = getSearchResponse(before5Minutes, nowTime)
        login5and10min = getSearchResponse(before10Minutes, before5Minutes)

        if logIn5min == True:
            print("sourceCategory.log.status %d %d" %(0, int(time.time())))
            return 0
        elif logIn5min == False and login5and10min == True:
            print("sourceCategory.log.status %d %d" %(1, int(time.time())))
            return 1
        elif logIn5min == False and login5and10min == False:
            print("sourceCategory.log.status %d %d" %(2, int(time.time())))
            return 2
        else:
            print("Unkonwn Error")
            return 3
    except Exception, e:
        print "CRITICAL - Internal Error:", e
            sys.exit(2)



if __name__ == '__main__':
    sys.exit(main())
