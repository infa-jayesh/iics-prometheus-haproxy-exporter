#!/usr/bin/python

####----------------------------------------
## This script checks if passed service is
## running or not. It also checks if its
## enabled or disabled
#### ---------------------------------------
## Use: $./serviceCheck.py --enabled true --service ip6tables
## client1.ip6tables.status 0 1497051560
#### ----if enabled is True/true-------------
## 0 --> running and enabled
## 1 --> running+disabled or enabled+not-sunnig
## 2 --> not running and is disabled
## 3 --> Somethig unexpected like different os
####-----------------------------------------
#### ----if enabled is False/false-----------
## 0 --> not running and is disabled
## 1 --> running+disabled or not running+enabled
## 2 --> running and enabled
## 3 --> Somethig unexpected like different os
####----------------------------------------

import sys
import os
import time
import argparse
from subprocess import Popen, PIPE


def check_service_status(state, service):
    '''
    This function checks the status of the service, which is passed as parameter.
    Based on the status, it do returns back the sensu metrics.
    '''
    try:
        hostname = os.uname()[1]
        executed = 0
        out = ""
        err = ""
        try:
            systemctl_res = Popen(['sudo', 'systemctl', 'status', service], stdout=PIPE, stderr=PIPE)
            out, err = systemctl_res.communicate()
            systemctl_res.stdout.close()
        except Exception, e:
            executed = 1

        if executed == 1 or 'systemctl: command not found' in err:
            try:
                service_res = Popen(['sudo', 'service', service, 'status'], stdout=PIPE, stderr=PIPE)
                out, err = service_res.communicate()
                service_res.stdout.close()
            except Exception, e:
                print "CRITICAL1 - Internal Error:", e
                sys.exit(3)

        if state == 'True' or state == 'true':
            if (('active (exited)' in out or 'active (running)' in out) and service + '.service; enabled;' in out) or ('is running' in out):
                print("%s : Running and Enabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 0, int(time.time())))
                return 0
            if ('active (exited)' in out or 'active (running)' in out) and service + '.service; disabled;' in out:
                print("%s : Running but Disabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 1, int(time.time())))
                return 1
            elif ('active (exited)' in out or 'inactive (dead)' in out) and service + '.service; enabled;' in out:
                print("%s : Not Running but Enabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 1, int(time.time())))
                return 1
            elif ((('active (exited)' not in out and 'active (running)' not in out) or 'inactive (dead)' in out) and service + '.service; disabled;' in out) or ('is stopped' in out) or 'is not running' in out:
                print("%s : Not Runnig and Disabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 2, int(time.time())))
                return 2
            elif ('could not be found' in err or 'unrecognized service' in err) and out == "":
                print("%s : Service not Found" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 3, int(time.time())))
                return 3
            else:
                print("%s : Unexpected Error" % (service))
                return 3
        elif state == 'False' or state == 'false':
            if (('active (exited)' in out or 'active (running)' in out) and service + '.service; enabled;' in out) or ('is running' in out):
                print("%s : Running and Enabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 2, int(time.time())))
                return 2
            if ('active (exited)' in out or 'active (running)' in out) and service + '.service; disabled;' in out:
                print("%s : Running but Disabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 1, int(time.time())))
                return 1
            if ('active (exited)' in out or 'inactive (dead)' in out) and service + '.service; enabled;' in out:
                print("%s : Not Running but Enabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 1, int(time.time())))
                return 1

            elif ((('active (exited)' not in out and 'active (running)' not in out) or 'inactive (dead)' in out) and service + '.service; disabled;' in out) or ('is stopped' in out) or 'is not running' in out:
                print("%s : Not Runnig and Disabled" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 0, int(time.time())))
                return 0
            elif ('could not be found' in err or 'unrecognized service' in err) and out == "":
                print("%s : Service not Found" % (service))
                print("%s.%s.status %d %d" % (hostname, service, 3, int(time.time())))
                return 3
            else:
                print("%s : Unexpected Error" % (service))
                return 3

    except Exception, e:
        print "CRITICAL - Internal Error:", e
        sys.exit(3)


def main(args):
    try:
        #for arg in args:
            #return(check_service_status(arg))
        parser = argparse.ArgumentParser(description='Check if a process is enabled or not. If enabled, started or not')
        parser.add_argument('--enabled', '-e', choices=['true', 'false', 'True', 'False'], help='Check if enabled or disabled')
        parser.add_argument('--service', '-s', help='Service Name')
        args = parser.parse_args()
        return(check_service_status(args.enabled, args.service))

    except Exception, e:
        print "CRITICAL - Internal Error:", e
        sys.exit(2)


if __name__ == '__main__':
    args = sys.argv[1:2]
    sys.exit(main(args))
