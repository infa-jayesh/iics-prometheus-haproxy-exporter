name             'my-sensu-setup'
maintainer       'CloudTrust'
maintainer_email ''
license          'All rights reserved'
description      'Configures my-sensu-setup'
long_description 'Configures my-sensu-setup'
version          '0.1.0'

