default['sensu']['clientcheckloglevel'] = 'info'
default['sensu']['environment'] = [ 'PROD' ]
default['sensu']['handler'] = 'opsgenie'
default['sensu']['contact'] = 'test_team'
default['sensu']['playbook'] = 'https://infawiki.informatica.com'
default['sensu']['rabbitmq'] = [
  {
    'host' => '127.0.0.1',
    'port' => '5672',
    'vhost' => '/sensu',
    'user' => 'sensu',
    'password' => 'secret'
  }
]
