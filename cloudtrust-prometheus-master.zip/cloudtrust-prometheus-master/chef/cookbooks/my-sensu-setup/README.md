# my-sensu-setup cookbook

Configures Sensu Client for ICHS Production and NonProduction

## Supported Platforms

RHEL 6, RHEL 7, Centos 7

## Attributes

- See attributes/default.rb

## Usage

1. Edit attributes/default.rb or use Chef environment to override
2. Substitute the following variables:
    - `environment` : Should be one of DEV, QA, PREVIEW, PROD
    - `handler` : Should be one of default, opsgenie
    - `contact` : Should be valid OpsGenie team. It's also the same value as the ALERTGROUP tag.
    - `rabbitmq`: Should be list of all RabbitMQs that are connected to Sensu Server
3. Add a new recipe for the application that is being customized. The sampleapp recipe can be used as a template.
   There should be one recipe for each application that is being customized.
4. Add the newly created recipe to your run_list. For example,

```json
{
  "run_list": [
    "recipe[my-sensu-setup::client], recipe[my-sensu-setup::metrics], recipe[my-sensu-setup::sampleapp]"
  ]
}
```

## License and Authors

Author:: YOUR_NAME (<YOUR_EMAIL>)
