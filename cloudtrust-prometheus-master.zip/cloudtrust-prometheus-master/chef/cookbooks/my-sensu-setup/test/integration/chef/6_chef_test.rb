# for files that exist but don't have specific permission
files = ['/etc/sensu/conf.d/checks-chef.json']
files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

describe file('/var/log/sensu/sensu-client.log') do
  its('content') {should match(%r{^\{"timestamp":".[^"]*","level":".[^"]*","message":"config file applied changes".*})}
end

describe json('/etc/sensu/conf.d/checks-chef.json') do
  its(['checks','chefnginx', 'command']) { should eq '/opt/sensu/embedded/bin/check-log.rb -f /var/log/opscode/nginx/access.log -q 504' }
  its(['checks','chefhastatus', 'command']) { should eq '/opt/sensu/embedded/bin/check-cmd.rb -c chef-server-ctl ha-status' }
end

# turn off test for OS version 7.0 + as SystemD has issues with services in Docker
if os[:release].to_f < 7.0
  describe service('sensu-client') do
    it { should be_enabled }
    it { should be_running }
  end
end
