packages = ['sysstat', 'bc', 'nagios-plugins-perl', 'perl-YAML-Syck', 'perl-Test-Simple', 'perl-Time-HiRes', 'sensu', 'perl-Sys-Statistics-Linux']
packages.each do |pkg|
  describe package(pkg) do
    it { should be_installed }
  end
end

# for files that should be executable
execfiles = ['/opt/sensu/embedded/bin/check-cpu.rb', '/opt/sensu/embedded/bin/check-memory-percent.rb', '/opt/sensu/embedded/bin/check-disk-usage.rb', '/opt/sensu/embedded/bin/check-load.rb', '/usr/lib64/nagios/plugins/check_bit9.py', '/usr/lib64/nagios/plugins/check_collector.py', '/usr/lib64/nagios/plugins/check_consul.sh', '/usr/lib64/nagios/plugins/check_dnsmasq.sh', '/usr/lib64/nagios/plugins/check_haproxy.py', '/usr/lib64/nagios/plugins/check_heap_no-heap.py', '/usr/lib64/nagios/plugins/check_linux_stats.pl', '/usr/lib64/nagios/plugins/check_mem.sh', '/usr/lib64/nagios/plugins/check_ntp.py', '/usr/lib64/nagios/plugins/check_qualys_proxy.sh', '/usr/lib64/nagios/plugins/check_selinux.py', '/usr/lib64/nagios/plugins/check_service.py', '/usr/lib64/nagios/plugins/check_sumo_log.py', '/usr/lib64/nagios/plugins/check_swap.sh', '/usr/lib64/nagios/plugins/check_vault.sh', '/usr/lib64/nagios/plugins/check_yum.sh', '/usr/lib64/nagios/plugins/getDiskUsage.py']
execfiles.each do |ef|
  describe file(ef) do
    its('mode') { should cmp '0755' }
  end
end

%w( sensu-plugins-disk-checks
    sensu-plugins-filesystem-checks
    sensu-plugins-load-checks
    sensu-plugins-memory-checks
    sensu-plugins-cpu-checks
    sensu-plugins-io-checks
    sensu-plugins-process-checks
    sensu-plugins-ntp
    sensu-plugins-logs
    sensu-plugins-http
    sensu-plugins-java
    sensu-plugins-ssl
    sensu-plugins-haproxy
    sensu-plugins-consul
    sensu-plugins-rabbitmq).each do |sensugem|
    describe command("/opt/sensu/embedded/bin/gem list --local -a -q #{sensugem}") do
    its('exit_status') { should eq 0 }
  end
end

# for files that exist but don't have specific permission
files = ['/etc/sensu/conf.d/base_checks.json']
files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

metric_files=['/opt/sensu/embedded/bin/metrics-cpu-mpstat.rb','/opt/sensu/embedded/bin/metrics-cpu-pcnt-usage.rb','/opt/sensu/embedded/bin/metrics-cpu.rb','/opt/sensu/embedded/bin/metrics-dirsize.rb','/opt/sensu/embedded/bin/metrics-disk-capacity.rb','/opt/sensu/embedded/bin/metrics-disk.rb','/opt/sensu/embedded/bin/metrics-disk-usage.rb','/opt/sensu/embedded/bin/metrics-filesize.rb','/opt/sensu/embedded/bin/metrics-load.rb','/opt/sensu/embedded/bin/metrics-memory-percent.rb','/opt/sensu/embedded/bin/metrics-memory.rb','/opt/sensu/embedded/bin/metrics-nfsstat.rb','/opt/sensu/embedded/bin/metrics-ntpdate.rb','/opt/sensu/embedded/bin/metrics-ntpstats.rb','/opt/sensu/embedded/bin/metrics-numastat.rb','/opt/sensu/embedded/bin/metrics-per-process.rb','/opt/sensu/embedded/bin/metrics-processes-threads-count.rb','/opt/sensu/embedded/bin/metrics-process-status.rb','/opt/sensu/embedded/bin/metrics-process-uptime.rb','/opt/sensu/embedded/bin/metrics-user-pct-usage.rb']
metric_files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

describe file('/var/log/sensu/sensu-client.log') do
  its('content') {should match(%r{^\{"timestamp":".[^"]*","level":".[^"]*","message":"config file applied changes".*})}
end

describe json('/etc/sensu/conf.d/base_checks.json') do
  its(['checks','checkCPULoad', 'command']) { should eq '/opt/sensu/embedded/bin/check-load.rb' }
  its(['checks','checkNetwork', 'command']) { should eq '/usr/lib64/nagios/plugins/check_net.sh' }
  its(['checks','checkMemory', 'command']) { should eq '/opt/sensu/embedded/bin/check-memory-percent.rb -w 90 -c 93' }
  its(['checks','checkSwap', 'command']) { should eq '/usr/lib64/nagios/plugins/check_swap.sh' }
  its(['checks','checkYumUpdates', 'command']) { should eq '/usr/lib64/nagios/plugins/check_yum.sh' }
  its(['checks','serviceNTPLag', 'command']) { should eq '/usr/lib64/nagios/plugins/check_ntp_time -H pool.ntp.org' }
  its(['checks','seLinuxMode', 'command']) { should eq 'python /usr/lib64/nagios/plugins/check_selinux.py' }
  its(['checks','getDiskUsage', 'command']) { should eq 'python /usr/lib64/nagios/plugins/getDiskUsage.py /' }
  its(['checks','check_auditd', 'command']) { should eq 'sudo /usr/lib64/nagios/plugins/check_auditd.py' }
end

describe json('/etc/sensu/conf.d/metrics.json') do
  its(['checks','aws_credentials', 'command']) { should eq '/usr/lib64/nagios/plugins/metrics_aws.sh' }
  its(['checks','metrics-cpu-mpstat', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-cpu-mpstat.rb' }
  its(['checks','metrics-cpu-pcnt-usage', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-cpu-pcnt-usage.rb' }
  its(['checks','metrics-cpu', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-cpu.rb' }
  its(['checks','metrics-disk-capacity', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-disk-capacity.rb' }
  its(['checks','metrics-disk', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-disk.rb' }
  its(['checks','metrics-disk-usage', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-disk-usage.rb' }
  its(['checks','metrics-load', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-load.rb' }
  its(['checks','metrics-memory-percent', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-memory-percent.rb' }
  its(['checks','metrics-memory', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-memory.rb' }
  its(['checks','metrics-ntpdate', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-ntpdate.rb --server 0.pool.ntp.org' }
  its(['checks','metrics-ntpstats', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-ntpstats.rb' }
  its(['checks','metrics-processes-threads-count', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-processes-threads-count.rb' }
end

# turn off test for OS version 7.0 + as SystemD has issues with services in Docker
if os[:release].to_f < 7.0
  describe service('sensu-client') do
    it { should be_enabled }
    it { should be_running }
  end
end
