# for files that exist but don't have specific permission
files = ['/etc/sensu/conf.d/checks-rabbitmq.json']
files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

describe file('/var/log/sensu/sensu-client.log') do
  its('content') {should match(%r{^\{"timestamp":".[^"]*","level":".[^"]*","message":"config file applied changes".*})}
end

describe json('/etc/sensu/conf.d/checks-rabbitmq.json') do
  its(['checks','check-rabbitmq-alive', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-alive.rb' }
  its(['checks','check-rabbitmq-amqp-alive', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-amqp-alive.rb' }
  its(['checks','check-rabbitmq-cluster-health', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-cluster-health.rb' }
  its(['checks','check-rabbitmq-consumers', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-consumers.rb' }
  its(['checks','check-rabbitmq-messages', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-messages.rb' }
  its(['checks','check-rabbitmq-network-partitions', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-network-partitions.rb' }
  its(['checks','check-rabbitmq-node-health', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-node-health.rb' }
  its(['checks','check-rabbitmq-node-usage', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-node-usage.rb' }
  its(['checks','check-rabbitmq-queue-drain-time', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-queue-drain-time.rb' }
  its(['checks','check-rabbitmq-queue', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-queue.rb' }
  its(['checks','check-rabbitmq-stomp-alive', 'command']) { should eq '/opt/sensu/embedded/bin/check-rabbitmq-stomp-alive.rb' }
end

# turn off test for OS version 7.0 + as SystemD has issues with services in Docker
if os[:release].to_f < 7.0
  describe service('sensu-client') do
    it { should be_enabled }
    it { should be_running }
  end
end
