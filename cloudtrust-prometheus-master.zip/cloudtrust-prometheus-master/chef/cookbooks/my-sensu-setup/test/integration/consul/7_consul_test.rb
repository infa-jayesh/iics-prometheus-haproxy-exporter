# for files that exist but don't have specific permission
files = ['/etc/sensu/conf.d/checks-consul.json']
files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

describe file('/var/log/sensu/sensu-client.log') do
  its('content') {should match(%r{^\{"timestamp":".[^"]*","level":".[^"]*","message":"config file applied changes".*})}
end

describe json('/etc/sensu/conf.d/checks-consul.json') do
  its(['checks','check-consul-failures', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-failures.rb' }
  its(['checks','check-consul-kv-ttl', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-kv-ttl.rb' }
  its(['checks','check-consul-leader', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-leader.rb' }
  its(['checks','check-consul-maintenance', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-maintenance.rb' }
  its(['checks','check-consul-members', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-members.rb' }
  its(['checks','check-consul-servers', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-servers.rb' }
  its(['checks','check-consul-service-health', 'command']) { should eq '/opt/sensu/embedded/bin/check-consul-service-health.rb' }
end

# turn off test for OS version 7.0 + as SystemD has issues with services in Docker
if os[:release].to_f < 7.0
  describe service('sensu-client') do
    it { should be_enabled }
    it { should be_running }
  end
end
