# for files that exist but don't have specific permission
files = ['/etc/sensu/conf.d/sampleapp.json']
files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

describe file('/var/log/sensu/sensu-client.log') do
  its('content') {should match(%r{^\{"timestamp":".[^"]*","level":".[^"]*","message":"config file applied changes".*})}
end

describe json('/etc/sensu/conf.d/sampleapp.json') do
  its(['checks','check_sampleapp-process', 'command']) { should eq '/opt/sensu/embedded/bin/check-process.rb -p tomcat7 -C 1 -c 1' }
  its(['checks','metrics_sampleapp-process-status', 'command']) { should eq '/opt/sensu/embedded/bin/metrics-process-status.rb -p tomcat7' }
  its(['checks','metrics_sampleapp-curl', 'command']) { should eq "/opt/sensu/embedded/bin/metrics-curl.rb -a '-k' -u https://localhost:16006/sampleapp/isalive.html" }
end

# turn off test for OS version 7.0 + as SystemD has issues with services in Docker
if os[:release].to_f < 7.0
  describe service('sensu-client') do
    it { should be_enabled }
    it { should be_running }
  end
end
