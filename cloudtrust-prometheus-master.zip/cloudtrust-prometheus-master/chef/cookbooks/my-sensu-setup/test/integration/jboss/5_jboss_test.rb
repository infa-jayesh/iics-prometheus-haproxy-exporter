execfiles = ['/usr/lib64/nagios/plugins/check_heap_no-heap.py', '/usr/lib64/nagios/plugins/check_jboss.py']
execfiles.each do |ef|
  describe file(ef) do
    its('mode') { should cmp '0755' }
  end
end

# for files that exist but don't have specific permission
files = ['/etc/sensu/conf.d/checks-jboss.json']
files.each do |f|
  describe file(f) do
    it { should exist }
  end
end

describe json('/etc/sensu/conf.d/checks-jboss.json') do
  its(['checks','jbossStatus', 'command']) { should eq 'python /usr/lib64/nagios/plugins/check_jboss.py -H localhost -P 9990 -u jboss -p password' }
  its(['checks','jboossHeapUsage', 'command']) { should eq 'python /usr/lib64/nagios/plugins/check_heap_no-heap.py -H localhost -P 9990 -u jboss -p password -A heap_usage' }
end

