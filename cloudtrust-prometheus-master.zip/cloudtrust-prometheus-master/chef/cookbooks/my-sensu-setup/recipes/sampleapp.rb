# add sensu plugins needed by application
# See https://github.com/sensu-plugins for re-usable plugins
%w( sensu-plugins-tomcat ).each do |pkg|
  execute "sensu-install #{pkg}" do
    command "umask 022 && sensu-install -p #{pkg}"
    action :run
  end
end

#add sampleapp checks and metrics to the client
template '/etc/sensu/conf.d/sampleapp.json' do
  source 'sampleapp.json.erb'
  mode '0644'
  notifies :restart, 'service[sensu-client]', :delayed
end

execute "logrotate sensu once" do
  command "logrotate -f /etc/logrotate.d/sensu"
  notifies :restart, 'service[sensu-client]', :delayed
end

service 'sensu-client' do
  provider Chef::Provider::Service::Systemd if node['init_package'] == "systemd"
  action [:enable, :start]
end
