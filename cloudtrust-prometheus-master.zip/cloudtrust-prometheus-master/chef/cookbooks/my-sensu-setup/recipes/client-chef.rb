#
# Cookbook Name:: my-sensu-setup
# Recipe:: client-chef
#
# Copyright (C) 2016 YOUR_NAME
#
# All rights reserved - Do Not Redistribute
#

#configure client
template '/etc/sensu/conf.d/client.json' do
  source 'client.json.erb'
  mode '0644'
  notifies :restart, 'service[sensu-client]', :delayed
  action :create_if_missing
end

template '/etc/sensu/config.json' do
  source 'config.json.erb'
  mode '0644'
  notifies :restart, 'service[sensu-client]', :delayed
  action :create_if_missing
end

template '/etc/sensu/conf.d/transport.json' do
  source 'transport.json.erb'
  mode '0644'
  notifies :restart, 'service[sensu-client]', :delayed
  action :create_if_missing
end

#Add Chef Checks to the client. Standalone Checks
template '/etc/sensu/conf.d/checks-chef.json' do
  source 'checks-chef.json.erb'
  mode '0644'
  notifies :restart, 'service[sensu-client]', :delayed
end

execute "logrotate sensu once" do
  command "logrotate -f /etc/logrotate.d/sensu"
  notifies :restart, 'service[sensu-client]', :delayed
end

service 'sensu-client' do
  provider Chef::Provider::Service::Systemd if node['init_package'] == "systemd"
  action [:enable, :start]
end
