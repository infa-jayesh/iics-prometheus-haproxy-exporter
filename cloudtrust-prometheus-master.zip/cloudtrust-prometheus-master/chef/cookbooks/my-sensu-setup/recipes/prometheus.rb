# install
template '/etc/yum.repos.d/sensu.repo' do
  source 'sensu.repo.erb'
  mode '0644'
  not_if { ::File.exist?('/etc/yum.repos.d/artifactory.repo') }
end

package ['sudo', 'sysstat', 'bc', 'logrotate', 'nagios-plugins-perl', 'nagios-plugins-mailq', 'perl-Test-Simple', 'sensu'] do
  action :install
end

package 'gcc-c++' do
  action :install
  only_if '/opt/sensu/embedded/bin/gem list sensu-plugins-consul'
end

if node['platform_version'].to_f < 7.0
  package ['perl-Sys-Statistics-Linux','perl-YAML-Syck'] do
    action :install
  end
else
  rpm_package 'perl-YAML-Syck' do
    source 'http://infa-devops-open.s3.amazonaws.com/perl-YAML-Syck-1.27-3.el7.x86_64.rpm'
    not_if 'rpm -qa | grep perl-YAML-Syck'
    action :install
  end

  rpm_package 'perl-Sys-Statistics-Linux' do
    source 'http://infa-devops-open.s3.amazonaws.com/perl-Sys-Statistics-Linux-0.66-1.of.el7.noarch.rpm'
    not_if 'rpm -qa | grep perl-Sys-Statistics-Linux'
    action :install
  end
end

%w( sensu-plugins-disk-checks
    sensu-plugins-filesystem-checks
    sensu-plugins-load-checks
    sensu-plugins-memory-checks
    sensu-plugins-cpu-checks
    sensu-plugins-network-checks
    sensu-plugins-io-checks
    sensu-plugins-process-checks
    sensu-plugins-ntp
    sensu-plugins-logs
    sensu-plugins-http
    sensu-plugins-java
    sensu-plugins-ssl
    sensu-plugins-haproxy
    sensu-plugins-consul
    sensu-plugins-rabbitmq ).each do |pkg|

  execute "sensu-install #{pkg}" do
    command "umask 022 && sensu-install -p #{pkg}"
    action :run
  end
end

# Add sudo configuration for sensu so certain checks and metrics will pass
cookbook_file '/etc/sudoers.d/sensu' do
  source 'sensu-sudo'
  mode 00640
end

# Add other plugins
cookbook_file '/opt/sensu/embedded/bin/check-log.rb' do
  source 'scripts/check-log.rb'
  mode 00755
end

remote_directory "/usr/lib64/nagios/plugins" do
  source 'scripts'
  mode 00755
  files_mode 00755
end

# put this config in AMI since it rarely changes
template '/etc/sensu/conf.d/transport.json' do
  source 'transport.json.erb'
  owner 'sensu'
  group 'sensu'
  mode '0644'
end

# Add Health Checks to the client. Standalone Checks
template '/etc/sensu/conf.d/base_checks.json' do
  source 'checks.json.erb'
  owner 'sensu'
  group 'sensu'
  mode '0644'
end

# Add Prometheus checks
template '/etc/sensu/conf.d/prometheus_checks.json' do
  source 'prometheus.json.erb'
  owner 'sensu'
  group 'sensu'
  mode '0644'
end

# fix logrotate for sensu
ruby_block "Fix up sensu logrotate configuration" do
  block do
    f1 = Chef::Util::FileEdit.new('/etc/logrotate.d/sensu')
    f1.insert_line_after_match(/\s+kill -USR2 .*/, '        kill -HUP `cat /var/run/syslogd.pid 2> /dev/null` 2> /dev/null || true')
    f1.insert_line_after_match(/\s+kill -USR2 .*/, '        kill -HUP `cat /var/run/rsyslogd.pid 2> /dev/null` 2> /dev/null || true')
    f1.search_file_replace(/rotate .*/, 'rotate 3')
    f1.insert_line_after_match(/daily/, '    copytruncate')
    f1.insert_line_after_match(/compress/, '    create 0644 sensu sensu')
    f1.insert_line_after_match(/compress/, '    endscript')
    f1.insert_line_after_match(/compress/, '        /bin/true')
    f1.insert_line_after_match(/compress/, '    lastaction')
    f1.write_file
  end
  only_if { ::File.exist?('/etc/logrotate.d/sensu') }
  not_if { ::File.readlines('/etc/logrotate.d/sensu').grep(/.*rsyslogd.*/).any? }
end

# Delete backup file /etc/logrotate.d/sensu.old
file '/etc/logrotate.d/sensu.old' do
  action :delete
  only_if { File.exist? '/etc/logrotate.d/sensu.old' }
end

# remove unneeded packages after plugin installation
package 'gcc' do
  action :remove
end

execute 'yum-clean-all' do
  command 'yum clean all; rm -rf /var/lib/yum/yumdb'
  action :run
end
