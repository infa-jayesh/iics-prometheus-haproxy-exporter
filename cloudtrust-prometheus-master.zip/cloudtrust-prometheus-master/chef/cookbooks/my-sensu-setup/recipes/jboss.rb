#
# Cookbook Name:: co-sensu-client
# Recipe:: default
#
# Copyright (C) 2016 YOUR_NAME
#
# All rights reserved - Do Not Redistribute
#

#configure client
#Add Health Checks to the client. Standalone Checks
template '/etc/sensu/conf.d/checks-jboss.json' do
  source 'checks-jboss.erb'
  mode '0644'
  notifies :restart, 'service[sensu-client]', :delayed
end
