#
# Cookbook:: co_prometheus_server
# Recipe:: configure
#
# Copyright:: 2018, The Authors, All Rights Reserved.

# vault-grafana.erb
template "/tmp/vault-grafana.sh" do
  source "vault-grafana.erb"
  mode 0755
end

# Run /tmp/vault-grafana.sh
execute "Retrieve vault secrets" do
  command "sh /tmp/vault-grafana.sh"
end

# Get env_region details
ruby_block 'get env_region' do
   block do
      command1 = ". /etc/profile.d/instancetags.sh; echo $TAG_CONSUL_DATACENTER"
      command_out1 = shell_out(command1)
      node.default['env_region'] = command_out1.stdout
   end
end

ruby_block 'get env_region_name' do
   block do
      command1 = ". /etc/profile.d/instancetags.sh; echo $AWS_DEFAULT_REGION"
      command_out1 = shell_out(command1)
      node.default['env_region_name'] = command_out1.stdout
   end
end

# copy prometheus.yml from files
template '/tmp/prometheus.yml.ctmpl' do
  source 'prometheus.yml.ctmpl.erb'
  owner 'prometheus'
  group 'prometheus'
  notifies :restart, "service[prometheus]"
end

# Run consul-template
#if File.exist?('/root/.vault-token')
#  vToken = ::File.read('/root/.vault-token').chomp
execute "Retrieve vault secrets" do
    command ". /etc/profile.d/instancetags.sh; /usr/local/bin/consul-template -once -vault-token `cat /root/.vault-token` -template '/tmp/prometheus.yml.ctmpl:/etc/prometheus/prometheus.yml'; chown prometheus.prometheus /etc/prometheus/prometheus.yml"
end

# restart prometheus
service "prometheus" do
  action :restart
end
