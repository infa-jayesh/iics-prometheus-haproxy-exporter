#
# Cookbook:: co_prometheus_server
# Recipe:: blackbox_exporter
#
# Copyright:: 2018, The Authors, All Rights Reserved.

unless node['prometheus']['components']['blackbox_exporter']['install?']

  blackbox_exporter 'main' do
    web_listen_address node['prometheus']['components']['blackbox_exporter']['web_listen_address']
    config_file "/opt/prometheus/blackbox_exporter-#{node['prometheus']['components']['blackbox_exporter']['version']}.linux-amd64/blackbox.yml"
    timeout_offset node['prometheus']['components']['blackbox_exporter']['timeout_offset']
    log_level node['prometheus']['components']['blackbox_exporter']['log_level']

    action %i[install enable start]
  end
end


