# cookbook name
cookbook_name = 'co_prometheus_server'

# System user to use
default['prometheus']['user'] = 'prometheus'

# System group to use
default['prometheus']['group'] = 'prometheus'

# versions to download
default['prometheus']['components'] = {
  'prometheus' => {
    'install?' => false,
    'version' => '2.4.2',
    'checksum' => 'cd32b6862eab4b5b6c5ed81a2aa951ebeba8b35506418c21d1f5f18fa346fcd0'
  },
  'blackbox_exporter' => {
    'install?' => false,
    'version' => '0.12.0',
    'checksum' => 'c5d8ba7d91101524fa7c3f5e17256d467d44d5e1d243e251fd795e0ab4a83605',
    'timeout_offset' => '0.5',
    'log_level' => 'info',
    'web_listen_address' => '0.0.0.0:9115'
  }
}

## versions to download
default['prometheus']['versions']['vault'] = '0.10.1'

# interpolate download url
default['prometheus']['downloads']['prometheus'] = "https://github.com/prometheus/prometheus/releases/download/v#{default['prometheus']['components']['prometheus']['version']}/prometheus-#{default['prometheus']['components']['prometheus']['version']}.linux-amd64.tar.gz"
default['prometheus']['downloads']['blackbox_exporter'] = "https://github.com/prometheus/blackbox_exporter/releases/download/v#{node['prometheus']['components']['blackbox_exporter']['version']}/blackbox_exporter-#{node['prometheus']['components']['blackbox_exporter']['version']}.linux-amd64.tar.gz"
default['prometheus']['downloads']['vault'] = "https://releases.hashicorp.com/vault/#{node['prometheus']['versions']['vault']}/vault_#{node['prometheus']['versions']['vault']}_linux_amd64.zip"

# interpolate folder names after we extract
default['prometheus']['folders']['prometheus'] = "prometheus-#{default['prometheus']['components']['prometheus']['version']}.linux-amd64"
default['prometheus']['folders']['vault'] = "vault_#{node['prometheus']['versions']['vault']}_linux_amd64"

#Grafana APIKEY
default['prometheus']['grafana']['url'] = 'https://prometheus-us-central1.grafana.net/api/prom/push'
default['prometheus']['grafana']['username'] = 461

#----------------------------------------------------------
#alertmanager attributes
# Directory where the Alert Manager binary will be installed
default['prometheus']['alertmanager']['dir'] = '/opt/prometheus/alertmanager'

# Location of Alert Manager binary
default['prometheus']['alertmanager']['binary'] = "#{node['prometheus']['alertmanager']['dir']}/alertmanager"

# Location of Alert Manager pid file
default['prometheus']['alertmanager']['pid'] = '/var/run/alertmanager.pid'

# Location for Alert Manager logs
default['prometheus']['alertmanager']['log_dir'] = '/var/log/alertmanager'

# Location for Alert Manager data
default['prometheus']['alertmanager']['data_dir'] = "#{node['prometheus']['alertmanager']['dir']}/data"

# Alert Manager version to build
default['prometheus']['alertmanager']['version'] = '0.14.0'

# Location for Alert Manager pre-compiled binary.
default['prometheus']['alertmanager']['binary_url'] = "https://github.com/prometheus/alertmanager/releases/download/v#{node['prometheus']['alertmanager']['version']}/alertmanager-#{node['prometheus']['alertmanager']['version']}.linux-amd64.tar.gz"

# Checksum for pre-compiled binary
default['prometheus']['alertmanager']['checksum'] = 'caddbbbe3ef8545c6cefb32f9a11207ae18dcc788e8d0fb19659d88c58d14b37'

# Location for Alert Manager config file
default['prometheus']['alertmanager']['config_file'] = "#{node['prometheus']['alertmanager']['dir']}/config.yml"

# Slack Alertmanager
default['prometheus']['alertmanager']['slack_webhook'] = ''

# The URL of the alert manager to send notifications to.
default['prometheus']['flags']['alertmanager.url'] = 'http://127.0.0.1:9093/alert-manager/'