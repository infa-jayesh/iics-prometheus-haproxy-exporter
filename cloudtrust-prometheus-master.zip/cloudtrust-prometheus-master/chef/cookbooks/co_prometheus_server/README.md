# co_prometheus_server

This cookbook installs the [Prometheus] monitoring system and time-series database.

Requirements
------------
- Chef 12 or higher

Platform
--------
Tested on

* Centos 7.5.1804

Attributes
----------
In order to keep the README managable and in sync with the attributes, this
cookbook documents attributes inline. The usage instructions and default
values for attributes can be found in the individual attribute files.

Recipes
-------

### default
Nothing

### install
The `install` recipe installs creates all the default [Prometheus] directories,
config files and and users. This also configures Prometheus to run under a process 
supervisor. The `configure` recipe configures all the exporteres.

Resource/Provider
-----------------

### prometheus_job
Not configured yet

## Usage

### First create the vault token for the grafana password. Seceret path is secret/cloudtrust/prometheus and key is password for key-value pair

### prometheus::install
