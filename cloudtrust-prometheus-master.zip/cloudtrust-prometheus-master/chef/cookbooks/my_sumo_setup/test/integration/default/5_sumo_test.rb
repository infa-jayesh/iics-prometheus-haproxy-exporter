# define packages
describe package('SumoCollector') do
  it { should be_installed }
end

describe file('/opt/SumoCollector/config/user.properties') do
  it { should be_file }
  its('content') { should match(/^syncSources.*/) }
end
