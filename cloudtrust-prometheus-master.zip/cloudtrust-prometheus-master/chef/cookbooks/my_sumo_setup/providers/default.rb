use_inline_resources

def whyrun_supported?
  true
end

action :add do
  service 'collector' do
    if node['platform_version'].to_i > 6
      provider Chef::Provider::Service::Systemd
    end
    supports restart: true
    action :enable
  end

  directory '/opt/SumoCollector/installerSources' do
    recursive true
  end

  directory '/opt/SumoCollector/config' do
    recursive true
  end

  remote_directory "/opt/SumoCollector/installerSources" do
    source 'sources'
    mode 00755
    files_mode 00644
  end

  template '/opt/SumoCollector/installerSources/default_logs.json' do
    cookbook 'my_sumo_setup'
    source 'default-logs.json.erb'
    variables(
      config: new_resource
    )
    mode 00644
    notifies :restart, 'service[collector]'
  end

  template '/opt/SumoCollector/installerSources/app_logs.json' do
    cookbook 'my_sumo_setup'
    source 'app_logs.json.erb'
    variables(
      config: new_resource
    )
    mode 00644
    notifies :restart, 'service[collector]'
  end

  template '/opt/SumoCollector/config/user.properties' do
    source 'user.properties.erb'
    variables(
      config: new_resource
    )
    mode 00644
    notifies :restart, 'service[collector]'
  end
end
