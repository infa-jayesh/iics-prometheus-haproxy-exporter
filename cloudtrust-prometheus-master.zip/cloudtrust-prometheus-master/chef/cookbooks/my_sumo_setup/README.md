# my_sumo_setup

- Configures the sumologic client

## Supported Platforms

- CentOS and RHEL 6.x and 7.x

## Attributes

- See attributes/default.rb

## Usage

1. Edit attributes/default.rb or use Chef environment to override
2. Substitute the following variables :
    - `accessid` : Should be set to your Sumologic Access ID
    - `accesskey` : Should be set to your Sumologic Access Key
    - `BU` : Set to your Business Unit
    - `environment` : Should be set to DEV, QA, PREVIEW, PROD
3. To add Sumologic JSON sources do any or all of the following:
    - For complex/custom JSON source definition(s) add a valid Sumologic JSON source file(s)
      to the `files/default/sources` directory
    - For basic log configuration which only requires defining the source name, file(s),
      category, and cutoffrelativetime **add** your log definition to the `sources` attribute 
      in `attributes/default.rb`
      ```
      default['sumologic']['sources'] = [
        {
          'sourcetype' => 'LocalFile',
          'sourcedescription' => 'Sensu Client',
          'name' => 'sensuclient',
          'filepath' => '/var/log/sensu/sensu-client.log',
          'category' => "#{node['sumologic']['environment']}_#{node['sumologic']['BU']}_Sensu_Client",
          'cutoffrelativetime' => '-1d'
        },
        {
          'sourcetype' => 'LocalFile',
          'name' => 'sampleapplog',
          'filepath' => '/opt/tomcat7/logs/sampleapp.log',
          'category' => "#{node['sumologic']['environment']}_#{node['sumologic']['BU']}_App_Sample_AppLog",
          'cutoffrelativetime' => '-1d'
        },
        {
          'sourcetype' => 'LocalFile',
          'sourcedescription' => 'Tomcat Access',
          'name' => 'accesslog',
          'filepath' => '/opt/tomcat7/logs/localhost_access_logs.*.txt',
          'category' => "#{node['sumologic']['environment']}_#{node['sumologic']['BU']}_App_Tomcat_access",
          'cutoffrelativetime' => '-1d'
        }
      ]
      ```
4. Add the newly created recipe to your run_list. For example,
    ```json
    {
      "run_list": [
        "recipe[my_sumo_setup]"
      ]
    }
    ```

## License and Authors

Author:: YOUR_NAME (<YOUR_EMAIL>)
