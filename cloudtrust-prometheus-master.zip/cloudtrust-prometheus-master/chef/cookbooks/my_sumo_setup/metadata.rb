name             'my_sumo_setup'
maintainer       ''
maintainer_email ''
license          'All rights reserved'
description      'Configures SumoLogic'
long_description 'Configures SumoLogic'
version          '0.3.0'

