# Directory for JSON log configuration files
