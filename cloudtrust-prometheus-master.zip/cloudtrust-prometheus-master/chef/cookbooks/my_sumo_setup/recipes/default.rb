my_sumo_setup node['sumologic']['collectorName'] do
  accessid node['sumologic']['accessid']
  accesskey node['sumologic']['accesskey']
  sources node['sumologic']['sources']
end
