default['sumologic']['collectorRPMUrl'] = 'https://collectors.sumologic.com/rest/download/rpm/64'
default['sumologic']['accessid'] = 'subEMxfspseCXW'
default['sumologic']['accesskey'] = 'UCmWCcJlbABgwuqp6VpeieF7ZiF3dvUOO7ogymosHv8T5eiYoFLWAA5g5Z6ULzRn'
default['sumologic']['BU'] = 'CLOUDTRUST'
# environment should be one of DEV, QA, PREVIEW, PROD
default['sumologic']['environment'] = 'PREVIEW'
# do not put this in the environments JSON file. Change format here.
default['sumologic']['collectorName'] = "#{node['sumologic']['BU']}_Installed_#{node['sumologic']['environment']}_AWS_mail_#{node['machinename']}"
default['sumologic']['sources'] = [
  {
    'sourcetype' => 'LocalFile',
    'sourcedescription' => 'Sensu Client',
    'name' => 'sensuclient',
    'filepath' => '/var/log/sensu/sensu-client.log',
    'category' => "#{node['sumologic']['BU'].downcase}/#{node['sumologic']['environment'].downcase}/prometheus/host/sensuclient",
    'cutoffrelativetime' => '-1d'
  }
]
