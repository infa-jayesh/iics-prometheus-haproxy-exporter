actions :add, :remove

default_action :add

attribute :accessid, kind_of: String, default: 'SOMEACCESSID'
attribute :accesskey, kind_of: String, default: 'SOMEACCESSKEY'
attribute :sources, kind_of: Array, default: []
